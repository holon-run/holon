//! A final RunOnce DTO borrows its original selected allocations through wire.
use super::{add_material, remaining_material, CapturedRunBirth};
use crate::runtime::{
    input_evidence_budget::{
        borrowed_json_material, BudgetViewGuard, InputEvidenceBudgetLedger, InputMemoryCategory,
        OwnedBytesEstimate, OwnedCompletionBudget,
    },
    input_queries::InputQueryError,
    resident_input_evidence::InputEvidenceScope,
};
use anyhow::{ensure, Context, Result};
use serde::Serialize;
use std::sync::Arc;

pub(crate) struct RunResponseMaterial {
    ledger: InputEvidenceBudgetLedger,
    scope: InputEvidenceScope,
    material: (u64, usize),
    owned: OwnedCompletionBudget,
    models: [Option<RunResponseModelMaterial>; 2],
}
/// Scope/ledger refer only to actual allocation observations, never read grants.
/// The response additionally owns the original selected Source and Task guards.
pub(crate) struct RunResponseMemory {
    ledger: InputEvidenceBudgetLedger,
    scope: InputEvidenceScope,
    material: (u64, usize),
    _guard: Arc<BudgetViewGuard>,
    models: [Option<RunResponseModelMaterial>; 2],
}

pub(crate) struct RunResponseModelMaterial {
    guard: Arc<BudgetViewGuard>,
    cost: (u64, usize),
}
#[derive(Clone, Copy)]
pub(crate) enum RunResponseModelSlot { Requested, Active }
impl RunResponseModelSlot {
    fn index(self) -> usize { match self { Self::Requested => 0, Self::Active => 1 } }
}
pub(super) fn from_original_source(
    source: &CapturedRunBirth,
    prior: (u64, usize),
) -> Result<RunResponseMaterial> {
    let ledger = source.inputs.actual_material_ledger(&source.token)?;
    let held = source.material_estimate()?;
    ensure!(
        prior.0 >= held.0 && prior.1 >= held.1,
        "response prior omits its original selected source"
    );
    let scope = &source.inputs.input.scope;
    let own = copy_material(scope)?;
    admit(ledger, prior, own)?;
    let owned = ledger.reserve_owned_completion(
        scope,
        InputMemoryCategory::Pins,
        OwnedBytesEstimate {
            payload_bytes: 0,
            metadata_estimate_bytes: own.0,
        },
    )?;
    // Includes these finite scope, ledger Arc, guard and owner headers before copy.
    Ok(RunResponseMaterial {
        ledger: ledger.clone(),
        scope: scope.clone(),
        material: add_material(prior, own)?,
        owned,
        models: [None, None],
    })
}
fn copy_material(value: &(impl Serialize + ?Sized)) -> Result<(u64, usize)> {
    let (encoded, nodes) = borrowed_json_material(&value)?;
    let exhausted = || InputQueryError::ResourceExhausted("Run response owned copy");
    let nodes = nodes
        .checked_add(16)
        .and_then(|n| n.checked_mul(8))
        .context(exhausted())?;
    let bytes = encoded
        .checked_mul(8)
        .and_then(|n| n.checked_add(u64::try_from(nodes).ok()?.checked_mul(256)?))
        .and_then(|n| n.checked_add(4096))
        .context(exhausted())?;
    Ok((bytes, nodes))
}
fn reserve(
    ledger: &InputEvidenceBudgetLedger,
    scope: &InputEvidenceScope,
    prior: (u64, usize),
    own: (u64, usize),
) -> Result<Arc<BudgetViewGuard>> {
    admit(ledger, prior, own)?;
    Ok(ledger.register_owned_bytes(
        scope,
        InputMemoryCategory::Pins,
        OwnedBytesEstimate {
            payload_bytes: 0,
            metadata_estimate_bytes: own.0,
        },
    )?)
}
fn admit(ledger: &InputEvidenceBudgetLedger, prior: (u64, usize), own: (u64, usize)) -> Result<()> {
    let left = remaining_material(ledger, (usize::MAX, usize::MAX), prior)?;
    ensure!(
        own.0 <= u64::try_from(left.0)? && own.1 <= left.1,
        InputQueryError::ResourceExhausted("Run response remaining material")
    );
    Ok(())
}
impl RunResponseMaterial {
    /// Call only with the borrowed fields actually copied into the response.
    /// Counting a complete Input/Root would admit unrelated bodies again.
    pub(crate) fn before_copy(&mut self, value: &(impl Serialize + ?Sized)) -> Result<()> {
        let own = copy_material(value)?;
        admit(&self.ledger, self.material, own)?;
        let next = add_material(self.material, own)?;
        // One original actual guard grows before the next owned copy. No
        // guard-vector reallocation or second allocation family is introduced.
        self.owned.observe_material(0, own.0);
        self.material = next;
        Ok(())
    }
    /// The prior route remains alive during parsing. A failed parse releases
    /// only this temporary; a successful replacement retires its old route.
    pub(crate) fn before_model_copy(&self, value: &(impl Serialize + ?Sized)) -> Result<RunResponseModelMaterial> {
        let cost = copy_material(value)?;
        let guard = reserve(&self.ledger, &self.scope, self.material, cost)?;
        Ok(RunResponseModelMaterial { guard, cost })
    }
    pub(crate) fn replace_model_material(&mut self, slot: RunResponseModelSlot, replacement: RunResponseModelMaterial) -> Result<()> {
        replacement.guard.validate_owned_material_binding(&self.scope, &self.ledger, replacement.cost.0)?;
        let index = slot.index();
        let previous = self.models[index].as_ref().map_or((0,0), |old| old.cost);
        let remaining = (self.material.0.checked_sub(previous.0).context("old response model bytes absent")?,
            self.material.1.checked_sub(previous.1).context("old response model nodes absent")?);
        self.material = add_material(remaining, replacement.cost)?;
        self.models[index] = Some(replacement);
        Ok(())
    }
    pub(crate) fn finish(self) -> RunResponseMemory {
        RunResponseMemory {
            ledger: self.ledger,
            scope: self.scope,
            material: self.material,
            _guard: self.owned.guard(),
            models: self.models,
        }
    }
}
impl RunResponseMemory {
    fn validate_model_material(&self) -> Result<()> {
        for model in self.models.iter().flatten() {
            model.guard.validate_owned_material_binding(&self.scope, &self.ledger, model.cost.0)?;
        }
        Ok(())
    }
    pub(crate) fn before_text(
        &self,
        value: &(impl Serialize + ?Sized),
    ) -> Result<Arc<BudgetViewGuard>> {
        self._guard
            .validate_owned_material_binding(&self.scope, &self.ledger, 0)?;
        self.validate_model_material()?;
        // Encoded bytes, pretty/text indentation and renderer container scratch
        // share this response's remaining phase before the final encoder runs.
        let own = copy_material(value)?;
        reserve(&self.ledger, &self.scope, self.material, own)
    }
    pub(crate) fn before_json(&self, encoded: usize) -> Result<Arc<BudgetViewGuard>> {
        self._guard
            .validate_owned_material_binding(&self.scope, &self.ledger, 0)?;
        self.validate_model_material()?;
        let bytes = u64::try_from(encoded)?
            .checked_add(8192)
            .context("Run JSON buffer overflow")?;
        reserve(&self.ledger, &self.scope, self.material, (bytes, 16))
    }
    pub(crate) fn material_estimate(&self) -> (u64, usize) {
        self.material
    }
}
