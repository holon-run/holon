//! RunOnce output keeps its original selected material through final encoding.
use super::*;
use crate::runtime::{
    input_evidence_budget::BudgetViewGuard,
    resident_input_evidence::PreparedInputEvidence,
    run_birth_sessions::{
        RunBirthBaseline, RunBirthReportProjection, RunFinalResponseSource, RunResponseMaterial,
        RunResponseMemory, RunResponseTasks, RunResponseModelSlot,
    },
};
use std::{fmt, io::Write, ops::Deref, sync::Arc};

struct ResponseData {
    value: RunOnceResponse,
    memory: RunResponseMemory,
    _source: RunFinalResponseSource,
}

/// Cloning this response shares the existing DTO and its actual source guards.
#[derive(Clone)]
pub struct OwnedRunOnceResponse(Arc<ResponseData>);
impl Deref for OwnedRunOnceResponse {
    type Target = RunOnceResponse;
    fn deref(&self) -> &Self::Target {
        &self.0.value
    }
}
impl fmt::Debug for OwnedRunOnceResponse {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.value.fmt(f)
    }
}
impl Serialize for OwnedRunOnceResponse {
    fn serialize<S: serde::Serializer>(
        &self,
        serializer: S,
    ) -> std::result::Result<S::Ok, S::Error> {
        self.0.value.serialize(serializer)
    }
}
impl OwnedRunOnceResponse {
    // Only the actual response builder constructs owned values under this phase.
    fn new(
        value: RunOnceResponse,
        memory: RunResponseMaterial,
        source: RunFinalResponseSource,
    ) -> Self {
        Self(Arc::new(ResponseData {
            value,
            memory: memory.finish(),
            _source: source,
        }))
    }

    /// The CLI and artifact writer use this owner instead of an escaping Value.
    pub fn json_wire(&self, pretty: bool) -> Result<RunOnceJson> {
        struct Counter(usize);
        impl Write for Counter {
            fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
                self.0 = self
                    .0
                    .checked_add(bytes.len())
                    .ok_or_else(|| std::io::Error::other("Run JSON size overflow"))?;
                Ok(bytes.len())
            }
            fn flush(&mut self) -> std::io::Result<()> {
                Ok(())
            }
        }
        let mut count = Counter(0);
        if pretty {
            serde_json::to_writer_pretty(&mut count, &self.0.value)?;
        } else {
            serde_json::to_writer(&mut count, &self.0.value)?;
        }
        let encoded = self.0.memory.before_json(count.0)?;
        let mut output = ExactJson {
            bytes: Vec::with_capacity(count.0),
            limit: count.0,
        };
        if pretty {
            serde_json::to_writer_pretty(&mut output, &self.0.value)?;
        } else {
            serde_json::to_writer(&mut output, &self.0.value)?;
        }
        anyhow::ensure!(
            output.bytes.len() == count.0,
            "Run JSON changed after admission"
        );
        Ok(RunOnceJson(Arc::new(JsonData {
            bytes: output.bytes,
            _response: self.clone(),
            _encoded: encoded,
        })))
    }

    pub fn render_text(&self) -> Result<RunOnceText> {
        let encoded = self.0.memory.before_text(&TextMaterial(&self.0.value))?;
        Ok(RunOnceText(Arc::new(TextData {
            text: self.0.value.render_text(),
            _response: self.clone(),
            _encoded: encoded,
        })))
    }
}
struct ExactJson {
    bytes: Vec<u8>,
    limit: usize,
}
impl Write for ExactJson {
    fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
        if self
            .bytes
            .len()
            .checked_add(bytes.len())
            .is_none_or(|n| n > self.limit)
        {
            return Err(std::io::Error::other("Run JSON exceeded admitted buffer"));
        }
        self.bytes.extend_from_slice(bytes);
        Ok(bytes.len())
    }
    fn flush(&mut self) -> std::io::Result<()> {
        Ok(())
    }
}
struct JsonData {
    bytes: Vec<u8>,
    _response: OwnedRunOnceResponse,
    _encoded: Arc<BudgetViewGuard>,
}
#[derive(Clone)]
pub struct RunOnceJson(Arc<JsonData>);
impl AsRef<[u8]> for RunOnceJson {
    fn as_ref(&self) -> &[u8] {
        &self.0.bytes
    }
}
struct TextData {
    text: String,
    _response: OwnedRunOnceResponse,
    _encoded: Arc<BudgetViewGuard>,
}
#[derive(Clone)]
pub struct RunOnceText(Arc<TextData>);
impl Deref for RunOnceText {
    type Target = str;
    fn deref(&self) -> &str {
        &self.0.text
    }
}
impl AsRef<[u8]> for RunOnceText {
    fn as_ref(&self) -> &[u8] {
        self.0.text.as_bytes()
    }
}
impl fmt::Display for RunOnceText {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0.text)
    }
}
impl fmt::Debug for RunOnceText {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.text.fmt(f)
    }
}

/// Count only strings and containers the text renderer actually copies.
struct TextMaterial<'a>(&'a RunOnceResponse);
impl Serialize for TextMaterial<'_> {
    fn serialize<S: serde::Serializer>(
        &self,
        serializer: S,
    ) -> std::result::Result<S::Ok, S::Error> {
        use serde::ser::SerializeTuple;
        let v = self.0;
        let mut tuple = serializer.serialize_tuple(8)?;
        tuple.serialize_element(&v.final_text)?;
        tuple.serialize_element(&v.sleep_reason)?;
        tuple.serialize_element(&v.token_usage)?;
        tuple.serialize_element(&v.provider_cache_usage)?;
        tuple.serialize_element(&v.requested_model)?;
        tuple.serialize_element(&v.active_model)?;
        tuple.serialize_element(&v.tasks.len())?;
        tuple.serialize_element(&TextTasks(&v.tasks))?;
        tuple.end()
    }
}
struct TextTasks<'a>(&'a [RunTaskSummary]);
impl Serialize for TextTasks<'_> {
    fn serialize<S: serde::Serializer>(
        &self,
        serializer: S,
    ) -> std::result::Result<S::Ok, S::Error> {
        use serde::ser::SerializeSeq;
        let mut seq = serializer.serialize_seq(Some(self.0.len()))?;
        for task in self.0 {
            seq.serialize_element(&(
                &task.task.status,
                task.task.summary.as_deref().unwrap_or(&task.task.kind),
                task.worktree.as_ref().map(|w| w.worktree_path.as_str()),
            ))?;
        }
        seq.end()
    }
}

pub(super) fn build_from_original_read(
    runtime: &RuntimeHandle,
    baseline: RunBirthBaseline,
    queued_agent_id: &str,
    final_status: RunFinalStatus,
    waiting_reason: Option<WaitingReason>,
    selected: RunResponseTasks,
    workspace_root: &Path,
) -> Result<OwnedRunOnceResponse> {
    let RunResponseTasks { tasks, source } = selected;
    let report = &source.poll.report;
    let state = &report.source.state;
    let mut phase = source.response_material(runtime)?;
    phase.before_copy(&(queued_agent_id, tasks.len()))?;
    let mut task_summaries = Vec::with_capacity(tasks.len());
    let mut changed_files = Vec::new();
    let mut sleep_reason = None;
    let mut tool_calls = 0usize;
    let mut exec_commands = 0usize;
    let mut batched = 0usize;
    let mut message_count = 0usize;
    for row in report.born_inputs() {
        match &row.record {
            PreparedInputEvidence::Message(_) => message_count += 1,
            PreparedInputEvidence::ToolExecution(tool) => {
                tool_calls += 1;
                exec_commands += usize::from(tool.tool_name == "ExecCommand");
                let projection = row.tool_run_report()?;
                batched = batched
                    .checked_add(projection.batched_exec_command_items)
                    .context("Run batch count overflow")?;
                if let Some(reason) = projection.sleep_reason.as_ref() {
                    phase.before_copy(reason)?;
                    sleep_reason = Some(reason.clone());
                }
                for path in &projection.patch_paths {
                    phase.before_copy(path)?;
                    changed_files.push(path.clone());
                }
                for path in &projection.output_paths {
                    phase.before_copy(path)?;
                    changed_files.push(normalize_workspace_relative_path(path, workspace_root));
                }
            }
            _ => {}
        }
    }
    for task in tasks {
        let worktree = worktree_for_original_task(&task, report, &mut phase)?;
        if let Some(worktree) = &worktree {
            phase.before_copy(&worktree.changed_files)?;
            changed_files.extend(worktree.changed_files.iter().cloned());
        }
        // The Task body moves from the original renderer without a second clone.
        task_summaries.push(RunTaskSummary { task, worktree });
    }
    changed_files.sort();
    changed_files.dedup();
    let failure = (final_status == RunFinalStatus::Failed)
        .then(|| {
            state
                .last_runtime_failure
                .as_ref()
                .and_then(|f| f.failure_artifact.as_ref())
                .or_else(|| {
                    task_summaries
                        .iter()
                        .rev()
                        .find(|t| {
                            matches!(
                                t.task.status,
                                TaskStatus::Failed
                                    | TaskStatus::Cancelled
                                    | TaskStatus::Interrupted
                            )
                        })
                        .and_then(|t| t.task.failure_artifact.as_ref())
                })
        })
        .flatten();
    phase.before_copy(&failure)?;
    let failure_artifact = failure.cloned();
    let raw = source
        .poll
        .terminal_text
        .as_ref()
        .map(|v| v.as_str())
        .filter(|v| !v.is_empty());
    let raw_final_text = if let Some(raw) = raw {
        phase.before_copy(&raw)?;
        Some(raw.to_owned())
    } else if let Some(text) = original_assistant_text(report, &mut phase)? {
        Some(text)
    } else {
        let fallback = state
            .last_turn_terminal
            .as_ref()
            .filter(|v| v.turn_index > baseline.turn_index)
            .and_then(|v| v.last_assistant_message.as_deref())
            .or_else(|| {
                (final_status == RunFinalStatus::Failed)
                    .then(|| {
                        state
                            .last_runtime_failure
                            .as_ref()
                            .map(|v| v.summary.as_str())
                    })
                    .flatten()
            })
            .map(str::trim)
            .filter(|v| !v.is_empty());
        phase.before_copy(&fallback)?;
        fallback.map(str::to_owned)
    };
    let delivery = original_delivery_text(report)
        .or(raw_final_text.as_deref())
        .unwrap_or_default();
    phase.before_copy(&delivery)?;
    let final_text = delivery.to_owned();
    let mut requested_model = if let Some(route) = &state.last_requested_model {
        let material = phase.before_model_copy(route)?;
        let owned = route.clone();
        phase.replace_model_material(RunResponseModelSlot::Requested, material)?;
        Some(owned)
    } else { None };
    let mut active_model = if let Some(route) = &state.last_active_model {
        let material = phase.before_model_copy(route)?;
        let owned = route.clone();
        phase.replace_model_material(RunResponseModelSlot::Active, material)?;
        Some(owned)
    } else { None };
    let mut fallback_active = requested_model
        .as_ref()
        .zip(active_model.as_ref())
        .is_some_and(|(r, a)| r != a);
    let mut cache = ProviderCacheUsage {
        read_input_tokens: 0,
        creation_input_tokens: 0,
    };
    let mut saw_cache = false;
    for event in report
        .born_events()
        .filter(|e| e.kind == "provider_round_completed")
    {
        // The original parser and its temporary strings are covered before it runs.
        for (field, target, slot) in [
            ("requested_model", &mut requested_model, RunResponseModelSlot::Requested),
            ("active_model", &mut active_model, RunResponseModelSlot::Active),
        ] {
            if let Some(raw) = event.data.get(field).and_then(serde_json::Value::as_str) {
                let material = phase.before_model_copy(raw)?;
                if let Ok(route) = ModelRouteRef::parse_compatible(raw) {
                    *target = Some(route);
                    // The old owned route drops before its material is retired.
                    phase.replace_model_material(slot, material)?;
                }
            }
        }
        fallback_active = event
            .data
            .get("fallback_active")
            .and_then(serde_json::Value::as_bool)
            .unwrap_or_else(|| {
                requested_model
                    .as_ref()
                    .zip(active_model.as_ref())
                    .is_some_and(|(r, a)| r != a)
            });
        if let Some(value) = event
            .data
            .get("provider_cache_usage")
            .filter(|v| !v.is_null())
        {
            saw_cache = true;
            cache.read_input_tokens = cache.read_input_tokens.saturating_add(
                value
                    .get("read_input_tokens")
                    .and_then(serde_json::Value::as_u64)
                    .unwrap_or(0),
            );
            cache.creation_input_tokens = cache.creation_input_tokens.saturating_add(
                value
                    .get("creation_input_tokens")
                    .and_then(serde_json::Value::as_u64)
                    .unwrap_or(0),
            );
        }
    }
    let provider_cache_usage = saw_cache.then(|| {
        let total = cache
            .read_input_tokens
            .saturating_add(cache.creation_input_tokens);
        RunProviderCacheUsage {
            read_input_tokens: cache.read_input_tokens,
            creation_input_tokens: cache.creation_input_tokens,
            cacheable_input_tokens: total,
            hit_rate: (total != 0).then(|| cache.read_input_tokens as f64 / total as f64),
        }
    });
    let token_usage = TokenUsage::new(
        state
            .total_input_tokens
            .saturating_sub(baseline.total_input_tokens),
        state
            .total_output_tokens
            .saturating_sub(baseline.total_output_tokens),
    );
    let exec_command_items = exec_commands
        .checked_add(batched)
        .context("Run command count overflow")?;
    let value = RunOnceResponse {
        agent_id: queued_agent_id.to_owned(),
        final_status,
        waiting_reason,
        final_text,
        raw_final_text,
        sleep_reason,
        failure_artifact,
        tasks: task_summaries,
        message_count,
        changed_files,
        input_tokens: token_usage.input_tokens,
        output_tokens: token_usage.output_tokens,
        token_usage,
        provider_cache_usage,
        requested_model,
        active_model,
        fallback_active,
        model_rounds: state
            .total_model_rounds
            .saturating_sub(baseline.total_model_rounds),
        tool_calls,
        shell_commands: exec_command_items,
        exec_command_items,
        batched_exec_command_items: batched,
    };
    Ok(OwnedRunOnceResponse::new(value, phase, source))
}

fn original_delivery_text(report: &RunBirthReportProjection) -> Option<&str> {
    let promoted = |field: &str, brief: bool| {
        report
            .born_events()
            .filter(|e| e.kind == "work_item_completion_report_promoted")
            .filter_map(|e| e.data.get(field).and_then(serde_json::Value::as_str))
            .filter_map(move |id| {
                report.born_inputs().find_map(|row| match &row.record {
                    PreparedInputEvidence::Brief(b) if brief && b.id == id => Some(b.text.as_str()),
                    PreparedInputEvidence::LegacyDelivery(d) if !brief && d.id == id => {
                        Some(d.text.as_str())
                    }
                    _ => None,
                })
            })
            .last()
            .map(str::trim)
            .filter(|v| !v.is_empty())
    };
    promoted("brief_id", true)
        .or_else(|| promoted("delivery_summary_id", false))
        .or_else(|| {
            report
                .born_inputs()
                .rev()
                .find_map(|row| match &row.record {
                    PreparedInputEvidence::LegacyDelivery(d) => Some(d.text.as_str()),
                    _ => None,
                })
                .map(str::trim)
                .filter(|v| !v.is_empty())
        })
}
fn worktree_for_original_task(
    task: &TaskOutputSnapshot,
    report: &RunBirthReportProjection,
    phase: &mut RunResponseMaterial,
) -> Result<Option<RunWorktreeSummary>> {
    let value = report
        .born_inputs()
        .filter_map(|row| match &row.record {
            PreparedInputEvidence::Message(m) => Some(m),
            _ => None,
        })
        .filter(|m| m.kind == MessageKind::TaskResult)
        .filter(|m| {
            m.metadata
                .as_ref()
                .and_then(|v| v.get("task_id"))
                .and_then(serde_json::Value::as_str)
                == Some(task.task_id.as_str())
        })
        .filter_map(|m| m.metadata.as_ref())
        .find_map(|v| v.get("worktree"));
    if let Some(value) = value {
        let path = value
            .get("worktree_path")
            .and_then(serde_json::Value::as_str)
            .unwrap_or_default();
        let branch = value
            .get("worktree_branch")
            .and_then(serde_json::Value::as_str)
            .unwrap_or_default();
        let paths = value
            .get("changed_files")
            .and_then(serde_json::Value::as_array);
        struct SelectedChangedPaths<'a>(Option<&'a Vec<serde_json::Value>>);
        impl serde::Serialize for SelectedChangedPaths<'_> {
            fn serialize<S: serde::Serializer>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error> {
                serializer.collect_seq(self.0.into_iter().flatten().filter_map(serde_json::Value::as_str))
            }
        }
        phase.before_copy(&(path, branch, SelectedChangedPaths(paths)))?;
        Ok(Some(RunWorktreeSummary {
            worktree_path: path.into(),
            worktree_branch: branch.into(),
            changed_files: paths
                .into_iter()
                .flatten()
                .filter_map(serde_json::Value::as_str)
                .map(str::to_owned)
                .collect(),
            retained_for_review: value
                .get("retained_for_review")
                .and_then(serde_json::Value::as_bool),
            auto_cleaned_up: value
                .get("auto_cleaned_up")
                .and_then(serde_json::Value::as_bool),
        }))
    } else if let Some(worktree) = task
        .child_supervision
        .as_ref()
        .and_then(|v| v.worktree.as_ref())
    {
        phase.before_copy(&(
            &worktree.worktree_path,
            &worktree.worktree_branch,
            &worktree.changed_files,
        ))?;
        Ok(Some(worktree_summary_from_projection(worktree)))
    } else {
        Ok(None)
    }
}
fn original_assistant_text(
    report: &RunBirthReportProjection,
    phase: &mut RunResponseMaterial,
) -> Result<Option<String>> {
    for event in report.born_events().rev().filter(|e| {
        e.kind == "assistant_round_recorded"
            && e.data["visibility"] == "operator_visible"
            && e.data["has_text"].as_bool() == Some(true)
    }) {
        let Some(id) = event.data["assistant_round_id"].as_str() else {
            continue;
        };
        // Mandatory integration: the named return-dependency union supplies a
        // same-cut Present or proven Missing, including prebaseline transcripts.
        let row = report
            .source
            .inputs
            .input
            .records
            .iter()
            .find_map(|row| match &row.record {
                PreparedInputEvidence::Transcript(t) if t.id == id => Some(t),
                _ => None,
            });
        let Some(row) = row else {
            anyhow::bail!("Run assistant return dependency requires original preparation: {id}")
        };
        let Some(blocks) = row.data["blocks"].as_array() else {
            continue;
        };
        // Only selected text blocks are copied; ignored transcript fields stay borrowed.
        for text in blocks
            .iter()
            .filter(|v| v["type"] == "text")
            .filter_map(|v| v["text"].as_str())
            .map(str::trim)
            .filter(|v| !v.is_empty())
        {
            phase.before_copy(&text)?;
        }
        let text = blocks
            .iter()
            .filter(|v| v["type"] == "text")
            .filter_map(|v| v["text"].as_str())
            .map(str::trim)
            .filter(|v| !v.is_empty())
            .collect::<Vec<_>>()
            .join("\n\n");
        if !text.is_empty() {
            return Ok(Some(text));
        }
    }
    Ok(None)
}
