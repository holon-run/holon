use std::{
    future::Future,
    path::{Path, PathBuf},
    time::{Duration, Instant},
};

use anyhow::{bail, Context, Result};
use serde::Serialize;
use std::sync::Arc;
use tokio::task::JoinHandle;

use crate::{
    config::{AppConfig, ModelRouteRef},
    host::RuntimeHost,
    ingress::InboundRequest,
    provider::ProviderCacheUsage,
    runtime::{
        run_birth_sessions::{RetainedRunTerminalText, RunBirthSessions, RunPollActivity},
        RuntimeHandle,
    },
    system::{WorkspaceAccessMode, WorkspaceProjectionKind},
    types::{
        AdmissionContext, AgentStatus, AuditEvent, AuthorityClass, ClosureOutcome, FailureArtifact,
        MessageBody, MessageDeliverySurface, MessageEnvelope, MessageKind, MessageOrigin, Priority,
        TaskOutputSnapshot, TaskRecord, TaskStatus, TokenUsage, ToolExecutionRecord,
        ToolExecutionStatus, TurnBudget, WaitingReason,
    },
};

#[path = "run_once_response.rs"]
mod response;
pub use response::{OwnedRunOnceResponse, RunOnceJson, RunOnceText};

const RUN_POLL_INTERVAL_MS: u64 = 100;
const RUN_QUIESCENCE_WINDOW_MS: u64 = 350;
const RUN_STOP_SETTLE_TIMEOUT_MS: u64 = 2_000;
const RUN_STOP_SETTLE_MIN_PER_TASK_MS: u64 = 100;

#[derive(Debug, Clone)]
pub struct RunOnceRequest {
    pub text: String,
    pub authority_class: AuthorityClass,
    pub agent_id: Option<String>,
    pub create_agent: bool,
    pub template: Option<String>,
    pub max_turns: Option<u64>,
    pub timeout_seconds: Option<u64>,
    pub wait_for_tasks: bool,
    pub workspace_root: Option<PathBuf>,
    pub cwd: Option<PathBuf>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum RunFinalStatus {
    Completed,
    Waiting,
    Failed,
    MaxTurnsExceeded,
}

#[derive(Debug, Clone, Serialize)]
pub struct RunTaskSummary {
    pub task: TaskOutputSnapshot,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub worktree: Option<RunWorktreeSummary>,
}

#[derive(Debug, Clone, Serialize)]
pub struct RunWorktreeSummary {
    pub worktree_path: String,
    pub worktree_branch: String,
    pub changed_files: Vec<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub retained_for_review: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub auto_cleaned_up: Option<bool>,
}

#[derive(Debug, Clone, Serialize)]
pub struct RunProviderCacheUsage {
    pub read_input_tokens: u64,
    pub creation_input_tokens: u64,
    pub cacheable_input_tokens: u64,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub hit_rate: Option<f64>,
}

#[derive(Debug, Clone, Serialize)]
pub struct RunOnceResponse {
    pub agent_id: String,
    pub final_status: RunFinalStatus,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub waiting_reason: Option<WaitingReason>,
    pub final_text: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub raw_final_text: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub sleep_reason: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub failure_artifact: Option<FailureArtifact>,
    pub tasks: Vec<RunTaskSummary>,
    pub message_count: usize,
    pub changed_files: Vec<String>,
    pub token_usage: TokenUsage,
    pub input_tokens: u64,
    pub output_tokens: u64,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub provider_cache_usage: Option<RunProviderCacheUsage>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub requested_model: Option<ModelRouteRef>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub active_model: Option<ModelRouteRef>,
    pub fallback_active: bool,
    pub model_rounds: u64,
    pub tool_calls: usize,
    pub shell_commands: usize,
    pub exec_command_items: usize,
    pub batched_exec_command_items: usize,
}

impl RunOnceResponse {
    pub fn render_text(&self) -> String {
        let mut sections = Vec::new();

        if !self.final_text.trim().is_empty() {
            sections.push(self.final_text.trim().to_string());
        }

        if self.final_status != RunFinalStatus::Completed {
            sections.push(format!(
                "Run status: {}",
                final_status_label(self.final_status)
            ));
        }

        if let Some(reason) = self.waiting_reason {
            sections.push(format!("Waiting reason: {}", waiting_reason_label(reason)));
        }

        if let Some(reason) = self.sleep_reason.as_ref() {
            sections.push(format!("Sleep reason: {reason}"));
        }

        if !self.token_usage.is_zero() {
            sections.push(format!(
                "Token usage: input {}, output {}, total {}",
                self.token_usage.input_tokens,
                self.token_usage.output_tokens,
                self.token_usage.total_tokens
            ));
        }

        if let Some(cache_usage) = self.provider_cache_usage.as_ref() {
            let hit_rate = cache_usage
                .hit_rate
                .map(|value| format!("{:.1}%", value * 100.0))
                .unwrap_or_else(|| "n/a".to_string());
            sections.push(format!(
                "Provider cache: read {}, created {}, hit rate {}",
                cache_usage.read_input_tokens, cache_usage.creation_input_tokens, hit_rate
            ));
        }

        if let Some(active_model) = self.active_model.as_ref() {
            let mut line = format!("Model: {}", active_model.as_compact_display());
            if let Some(requested_model) = self.requested_model.as_ref() {
                if requested_model != active_model {
                    line.push_str(&format!(
                        " (requested {})",
                        requested_model.as_compact_display()
                    ));
                }
            }
            sections.push(line);
        }

        if !self.tasks.is_empty() {
            let task_lines = self
                .tasks
                .iter()
                .map(|task| {
                    let mut line = format!(
                        "- [{}] {}",
                        task_status_label(&task.task.status),
                        task.task.summary.as_deref().unwrap_or(&task.task.kind)
                    );
                    if let Some(worktree) = task.worktree.as_ref() {
                        line.push_str(&format!(" ({})", worktree.worktree_path));
                    }
                    line
                })
                .collect::<Vec<_>>();
            sections.push(format!("Tasks:\n{}", task_lines.join("\n")));
        }

        if sections.is_empty() {
            "Run completed without additional output.".to_string()
        } else {
            sections.join("\n\n")
        }
    }
}

pub async fn run_once(config: AppConfig, request: RunOnceRequest) -> Result<OwnedRunOnceResponse> {
    std::fs::create_dir_all(config.agent_root_dir())?;
    std::fs::create_dir_all(config.run_dir())?;
    let host = RuntimeHost::new(config)?;
    run_once_with_host(host, request).await
}

pub fn run_once_with_host(
    host: RuntimeHost,
    request: RunOnceRequest,
) -> impl Future<Output = Result<OwnedRunOnceResponse>> + Send {
    Box::pin(run_once_with_host_inner(host, request))
}

async fn run_once_with_host_inner(
    host: RuntimeHost,
    request: RunOnceRequest,
) -> Result<OwnedRunOnceResponse> {
    let session = prepare_run_session(&host, &request).await?;
    bind_run_workspace(&host, &session.runtime, &request, session.is_persistent).await?;
    let sessions = session.runtime.begin_run_birth_sessions().await?;
    let baseline = sessions.baseline;

    let inbound = InboundRequest {
        agent_id: session.agent_id.clone(),
        kind: MessageKind::OperatorPrompt,
        priority: Priority::Normal,
        origin: MessageOrigin::Operator {
            actor_id: Some("holon_run".into()),
            actor_display_name: None,
        },
        authority_class: request.authority_class.clone(),
        body: MessageBody::Text {
            text: request.text.clone(),
        },
        delivery_surface: MessageDeliverySurface::RunOnce,
        admission_context: AdmissionContext::LocalProcess,
        work_item_id: None,
        metadata: None,
        correlation_id: None,
        causation_id: None,
        trace_context: None,
    };
    // Set turn budget before enqueueing the message so the turn execution
    // pipeline can inject a budget warning on the last allowed turn.
    if let Some(max_turns) = request.max_turns {
        let run_start_turn_index = baseline.turn_index;
        session
            .runtime
            .update_agent_state(|state| {
                state.turn_budget = Some(TurnBudget {
                    max_turns,
                    run_start_turn_index,
                });
                Ok(())
            })
            .await?;
    }

    let message = inbound.into_message();
    let queued_message = session.runtime.enqueue(message).await?;

    let mut candidate_completion: Option<CandidateCompletion> = None;
    let mut observed_terminal_final_text: Option<Arc<RetainedRunTerminalText>> = None;
    let run_started_at = Instant::now();
    let mut timeout_warning_due = false;
    let mut timeout_warning_sent = false;
    let mut timeout_warning_turn_index = None;

    let final_candidate = loop {
        let read = session
            .runtime
            .capture_run_poll_read(&sessions, observed_terminal_final_text.clone())
            .await?;
        let state = &read.report.source.state;
        let poll_view = read.poll;
        observed_terminal_final_text = read.terminal_text.clone();
        let active_new_task_ids = &read.active_task_ids;
        let foreground_idle = state.current_run_id.is_none() && state.pending == 0;
        let turns_elapsed = state.turn_index.saturating_sub(baseline.turn_index);
        let max_turns_hit = request.max_turns.is_some_and(|max| turns_elapsed >= max);
        let terminal_within_max_turns = request.max_turns.is_none_or(|max| turns_elapsed <= max);

        let terminal_status = if foreground_idle && poll_view.turn_terminal_observed {
            read.closure.as_ref().map(|closure| {
                (
                    match closure.outcome {
                        ClosureOutcome::Completed => RunFinalStatus::Completed,
                        ClosureOutcome::Continuable => RunFinalStatus::Waiting,
                        ClosureOutcome::Failed => RunFinalStatus::Failed,
                        ClosureOutcome::Waiting => RunFinalStatus::Waiting,
                    },
                    closure.waiting_reason,
                )
            })
        } else {
            None
        };
        if !foreground_idle
            && request
                .timeout_seconds
                .is_some_and(|seconds| run_started_at.elapsed() >= Duration::from_secs(seconds))
        {
            timeout_warning_due = true;
        }
        let terminal_final_text_observed = observed_terminal_final_text.is_some()
            || poll_view.operator_visible_assistant_text_observed;

        let waiting_for_active_tasks = request.wait_for_tasks && !active_new_task_ids.is_empty();
        if !timeout_warning_sent
            && timeout_warning_due
            && foreground_idle
            && !max_turns_hit
            && terminal_status.is_some()
        {
            let timeout_message = InboundRequest {
                agent_id: session.agent_id.clone(),
                kind: MessageKind::InternalFollowup,
                priority: Priority::Interject,
                origin: MessageOrigin::System {
                    subsystem: "solve_timeout".into(),
                },
                authority_class: AuthorityClass::RuntimeInstruction,
                body: MessageBody::Text {
                    text: "The solve soft timeout has been reached. Stop starting new work, finish the current task, publish the best available summary and review/result artifacts, and then end the run.".into(),
                },
                delivery_surface: MessageDeliverySurface::RuntimeSystem,
                admission_context: AdmissionContext::RuntimeOwned,
                work_item_id: None,
                metadata: None,
                correlation_id: None,
                causation_id: None,
                trace_context: None,
            };
            session
                .runtime
                .enqueue(timeout_message.into_message())
                .await?;
            session.runtime.append_audit_event(
                "solve_timeout_warning_injected",
                serde_json::json!({
                    "agent_id": session.agent_id,
                    "timeout_seconds": request.timeout_seconds,
                }),
            )?;
            timeout_warning_sent = true;
            timeout_warning_turn_index = Some(state.turn_index);
            candidate_completion = None;
        }
        let timeout_follow_up_terminal =
            timeout_warning_turn_index.is_none_or(|warning_turn_index| {
                state
                    .last_turn_terminal
                    .as_ref()
                    .is_some_and(|record| record.turn_index > warning_turn_index)
            });
        let candidate_status = if poll_view.runtime_error && foreground_idle {
            Some((RunFinalStatus::Failed, None))
        } else if timeout_warning_sent && !timeout_follow_up_terminal {
            None
        } else if (matches!(terminal_status, Some((RunFinalStatus::Failed, _)))
            && terminal_within_max_turns)
            || (terminal_final_text_observed
                && matches!(terminal_status, Some((RunFinalStatus::Completed, _))))
        {
            if waiting_for_active_tasks {
                None
            } else {
                terminal_status
            }
        } else if max_turns_hit && foreground_idle {
            if waiting_for_active_tasks {
                None
            } else {
                Some((RunFinalStatus::MaxTurnsExceeded, None))
            }
        } else if terminal_status.is_some() {
            if waiting_for_active_tasks {
                None
            } else {
                terminal_status
            }
        } else {
            None
        };

        if let Some((status, waiting_reason)) = candidate_status {
            if let Some(candidate) = candidate_completion.as_ref() {
                if candidate.state == status
                    && candidate.waiting_reason == waiting_reason
                    && candidate.activity_signature == poll_view.activity
                    && candidate.observed_at.elapsed()
                        >= Duration::from_millis(RUN_QUIESCENCE_WINDOW_MS)
                {
                    break candidate.clone();
                }
            }
            let should_reset_candidate = candidate_completion.as_ref().is_none_or(|candidate| {
                candidate.state != status
                    || candidate.waiting_reason != waiting_reason
                    || candidate.activity_signature != poll_view.activity
            });
            if should_reset_candidate {
                candidate_completion = Some(CandidateCompletion::new(
                    status,
                    waiting_reason,
                    poll_view.activity,
                ));
            }
        } else {
            candidate_completion = None;
        }

        drop(read);
        tokio::time::sleep(Duration::from_millis(RUN_POLL_INTERVAL_MS)).await;
    };
    // Clear turn budget now that the run has ended.
    // Errors are intentionally swallowed: the next run overwrites this field,
    // and a failure here must not mask the actual run result.
    let _ = session
        .runtime
        .update_agent_state(|state| {
            state.turn_budget = None;
            Ok(())
        })
        .await;

    let final_status = final_candidate.state;
    let waiting_reason = final_candidate.waiting_reason;
    let pre_cleanup = session
        .runtime
        .capture_run_poll_read(&sessions, observed_terminal_final_text.clone())
        .await?;
    for task_id in &pre_cleanup.active_task_ids {
        let _ = session
            .runtime
            .stop_task(task_id, &request.authority_class)
            .await;
    }
    settle_stopped_tasks(
        &session.runtime,
        &sessions,
        &pre_cleanup.active_task_ids,
        pre_cleanup.terminal_text.clone(),
        &request.authority_class,
    )
    .await?;
    drop(pre_cleanup);
    let selected = session
        .runtime
        .capture_run_final_read(&sessions, observed_terminal_final_text)
        .await?
        .render(&session.runtime)
        .await?
        .into_response_tasks(&session.runtime)?;
    let response = response::build_from_original_read(
        &session.runtime,
        baseline,
        &queued_message.agent_id,
        final_status,
        waiting_reason,
        selected,
        &session.runtime.workspace_root(),
    );

    match session.cleanup {
        RunSessionCleanup::Temporary { runtime_task } => {
            host.cleanup_temporary_runtime(session.agent_id, session.runtime, runtime_task)
                .await?;
        }
        RunSessionCleanup::Persistent => {
            host.unload_runtime(&session.agent_id).await;
        }
    }

    response
}

struct RunSession {
    agent_id: String,
    runtime: RuntimeHandle,
    cleanup: RunSessionCleanup,
    is_persistent: bool,
}

enum RunSessionCleanup {
    Temporary { runtime_task: JoinHandle<()> },
    Persistent,
}

async fn prepare_run_session(host: &RuntimeHost, request: &RunOnceRequest) -> Result<RunSession> {
    if request.template.is_some() && !request.create_agent {
        bail!("template requires create_agent=true");
    }

    if let Some(agent_id) = request.agent_id.as_deref() {
        if request.create_agent {
            host.create_public_named_agent(agent_id, request.template.as_deref(), None, None)
                .await?;
        }
        let runtime = host.get_public_agent_for_external_ingress(agent_id).await?;
        Ok(RunSession {
            agent_id: agent_id.to_string(),
            runtime,
            cleanup: RunSessionCleanup::Persistent,
            is_persistent: true,
        })
    } else {
        let (agent_id, runtime, runtime_task) = host.spawn_temporary_runtime("run").await?;
        Ok(RunSession {
            agent_id,
            runtime,
            cleanup: RunSessionCleanup::Temporary { runtime_task },
            is_persistent: false,
        })
    }
}

async fn bind_run_workspace(
    host: &RuntimeHost,
    runtime: &RuntimeHandle,
    request: &RunOnceRequest,
    preserve_existing_session: bool,
) -> Result<()> {
    let existing_state = runtime.agent_state().await?;
    let should_preserve_existing_workspace = preserve_existing_session
        && request.workspace_root.is_none()
        && request.cwd.is_none()
        && existing_state.active_workspace_entry.is_some();
    if should_preserve_existing_workspace {
        return Ok(());
    }

    let workspace_anchor = request
        .workspace_root
        .clone()
        .unwrap_or_else(|| host.config().workspace_dir.clone());
    let workspace = host.ensure_workspace_entry(workspace_anchor.clone())?;
    runtime.attach_workspace(&workspace).await?;
    let selected_cwd = request.cwd.clone().unwrap_or_else(|| {
        std::env::current_dir()
            .ok()
            .filter(|cwd| cwd.starts_with(&workspace_anchor))
            .unwrap_or(workspace_anchor.clone())
    });
    runtime
        .enter_workspace(
            &workspace,
            WorkspaceProjectionKind::CanonicalRoot,
            WorkspaceAccessMode::SharedRead,
            Some(selected_cwd),
            None,
        )
        .await?;
    Ok(())
}

#[derive(Debug, Clone)]
struct CandidateCompletion {
    state: RunFinalStatus,
    waiting_reason: Option<WaitingReason>,
    activity_signature: RunPollActivity,
    observed_at: Instant,
}

impl CandidateCompletion {
    fn new(
        state: RunFinalStatus,
        waiting_reason: Option<WaitingReason>,
        activity_signature: RunPollActivity,
    ) -> Self {
        Self {
            state,
            waiting_reason,
            activity_signature,
            observed_at: Instant::now(),
        }
    }
}

async fn settle_stopped_tasks(
    runtime: &crate::runtime::RuntimeHandle,
    sessions: &RunBirthSessions,
    task_ids: &[String],
    retained: Option<Arc<RetainedRunTerminalText>>,
    authority_class: &AuthorityClass,
) -> Result<()> {
    let deadline = Instant::now() + Duration::from_millis(RUN_STOP_SETTLE_TIMEOUT_MS);
    for (index, task_id) in task_ids.iter().enumerate() {
        loop {
            let Some(remaining) = deadline.checked_duration_since(Instant::now()) else {
                break;
            };
            let read = runtime
                .capture_run_poll_read(sessions, retained.clone())
                .await?;
            let status = read.task_status(task_id)?;
            if !crate::storage::is_active_task_status(&status) {
                break;
            }

            let _ = runtime.stop_task(task_id, authority_class).await;

            let tasks_left = task_ids.len().saturating_sub(index).max(1) as u128;
            let remaining_ms_u128 = remaining.as_millis();
            let fair_share_ms = (remaining_ms_u128 / tasks_left)
                .max(RUN_STOP_SETTLE_MIN_PER_TASK_MS as u128)
                .min(remaining_ms_u128);
            let remaining_ms = fair_share_ms.min(u64::MAX as u128) as u64;
            if remaining_ms == 0 {
                break;
            }

            let wait_started = Instant::now();
            let waited = loop {
                let read = runtime
                    .capture_run_poll_read(sessions, retained.clone())
                    .await?;
                let status = read.task_status(task_id)?;
                if !crate::storage::is_active_task_status(&status)
                    || wait_started.elapsed() >= Duration::from_millis(remaining_ms)
                {
                    break status;
                }
                tokio::time::sleep(Duration::from_millis(100).min(
                    Duration::from_millis(remaining_ms).saturating_sub(wait_started.elapsed()),
                ))
                .await;
            };
            if !crate::storage::is_active_task_status(&waited) {
                break;
            }
        }
    }
    Ok(())
}

fn worktree_summary_from_projection(
    worktree: &crate::types::ChildSupervisionWorktreeProjection,
) -> RunWorktreeSummary {
    RunWorktreeSummary {
        worktree_path: worktree.worktree_path.clone().unwrap_or_default(),
        worktree_branch: worktree.worktree_branch.clone().unwrap_or_default(),
        changed_files: worktree.changed_files.clone(),
        retained_for_review: worktree.retained_for_review,
        auto_cleaned_up: worktree.auto_cleaned_up,
    }
}

#[cfg(test)]
fn changed_files_from_tools(tools: &[ToolExecutionRecord], workspace_root: &Path) -> Vec<String> {
    let mut changed = Vec::new();
    for tool in tools {
        match tool.tool_name.as_str() {
            "ApplyPatch" => {
                let patch_input = tool
                    .input
                    .as_str()
                    .or_else(|| tool.input.get("patch").and_then(|value| value.as_str()));
                if let Some(input) = patch_input {
                    let parsed = extract_patch_files(input);
                    if !parsed.is_empty() {
                        changed.extend(parsed);
                        continue;
                    }
                }
                if let Some(paths) = tool
                    .output
                    .get("envelope")
                    .and_then(|value| value.get("result"))
                    .and_then(|value| value.get("changed_paths"))
                    .and_then(|value| value.as_array())
                {
                    changed.extend(
                        paths
                            .iter()
                            .filter_map(|path| path.as_str())
                            .map(|path| normalize_workspace_relative_path(path, workspace_root)),
                    );
                }
            }
            _ => {}
        }
    }
    changed
}

#[cfg(test)]
fn extract_patch_files(input: &str) -> Vec<String> {
    let mut changed = Vec::new();
    let mut pending_rename_from: Option<String> = None;
    let lines = input.lines().collect::<Vec<_>>();
    let mut index = 0usize;

    while index < lines.len() {
        let line = lines[index];
        if let Some(path) = line.strip_prefix("rename from ") {
            pending_rename_from = Some(strip_diff_prefix(path).to_string());
            index += 1;
            continue;
        }
        if let Some(path) = line.strip_prefix("rename to ") {
            if let Some(from) = pending_rename_from.take() {
                push_unique(&mut changed, from);
                push_unique(&mut changed, strip_diff_prefix(path).to_string());
            }
            index += 1;
            continue;
        }
        if let Some(old_path) = line.strip_prefix("--- ") {
            if index + 1 < lines.len() {
                if let Some(new_path) = lines[index + 1].strip_prefix("+++ ") {
                    let old_path = strip_diff_prefix(old_path);
                    let new_path = strip_diff_prefix(new_path);
                    if old_path != "/dev/null" {
                        push_unique(&mut changed, old_path.to_string());
                    }
                    if new_path != "/dev/null" && new_path != old_path {
                        push_unique(&mut changed, new_path.to_string());
                    }
                    index += 2;
                    continue;
                }
            }
        }
        index += 1;
    }

    changed
}

#[cfg(test)]
fn push_unique(values: &mut Vec<String>, value: String) {
    if !values.iter().any(|existing| existing == &value) {
        values.push(value);
    }
}

#[cfg(test)]
fn strip_diff_prefix(path: &str) -> &str {
    path.strip_prefix("a/")
        .or_else(|| path.strip_prefix("b/"))
        .unwrap_or(path)
}

fn normalize_workspace_relative_path(path: &str, workspace_root: &Path) -> String {
    let candidate = Path::new(path);
    if candidate.is_relative() {
        return path.to_string();
    }

    candidate
        .strip_prefix(workspace_root)
        .map(|relative| relative.to_string_lossy().into_owned())
        .unwrap_or_else(|_| path.to_string())
}

fn final_status_label(state: RunFinalStatus) -> &'static str {
    match state {
        RunFinalStatus::Completed => "completed",
        RunFinalStatus::Waiting => "waiting",
        RunFinalStatus::Failed => "failed",
        RunFinalStatus::MaxTurnsExceeded => "max_turns_exceeded",
    }
}

fn waiting_reason_label(reason: WaitingReason) -> &'static str {
    match reason {
        WaitingReason::AwaitingOperatorInput => "awaiting_operator_input",
        WaitingReason::AwaitingExternalChange => "awaiting_external_change",
        WaitingReason::AwaitingTaskResult => "awaiting_task_result",
        WaitingReason::AwaitingTimer => "awaiting_timer",
    }
}

fn task_status_label(state: &TaskStatus) -> &'static str {
    match state {
        TaskStatus::Queued => "queued",
        TaskStatus::Running => "running",
        TaskStatus::Cancelling => "cancelling",
        TaskStatus::Completed => "completed",
        TaskStatus::Failed => "failed",
        TaskStatus::Cancelled => "cancelled",
        TaskStatus::Interrupted => "interrupted",
    }
}

#[cfg(test)]
fn exec_command_task_id(tool: &ToolExecutionRecord) -> Option<&str> {
    if tool.tool_name != "ExecCommand" || tool.status != ToolExecutionStatus::Success {
        return None;
    }

    exec_command_result_value(&tool.output)
        .and_then(|value| value.get("task_handle"))
        .and_then(|value| value.get("task_id"))
        .and_then(|value| value.as_str())
}

#[cfg(test)]
fn exec_command_result_value(output: &serde_json::Value) -> Option<&serde_json::Value> {
    output
        .get("result")
        .or_else(|| output.get("envelope").and_then(|value| value.get("result")))
}

#[cfg(test)]
fn exec_command_event_task_id(event: &AuditEvent) -> Option<&str> {
    if event.kind != "tool_executed"
        || event.data.get("tool_name").and_then(|value| value.as_str()) != Some("ExecCommand")
        || event
            .data
            .get("status")
            .and_then(|value| value.as_str())
            .is_some_and(|status| status != "success")
    {
        return None;
    }

    event
        .data
        .get("task_handle")
        .and_then(|value| value.get("task_id"))
        .and_then(|value| value.as_str())
}

#[cfg(test)]
fn batched_exec_command_items(tools: &[ToolExecutionRecord]) -> usize {
    tools
        .iter()
        .filter(|tool| tool.tool_name == "ExecCommandBatch")
        .map(|tool| {
            let result = tool
                .output
                .get("envelope")
                .and_then(|value| value.get("result"));
            let completed_count = result
                .and_then(|value| value.get("completed_count"))
                .and_then(|value| value.as_u64())
                .map(|value| value as usize)
                .unwrap_or(0);
            let failed_count = result
                .and_then(|value| value.get("failed_count"))
                .and_then(|value| value.as_u64())
                .map(|value| value as usize)
                .unwrap_or(0);
            completed_count + failed_count
        })
        .sum()
}

#[cfg(test)]
fn aggregate_provider_cache_usage(events: &[AuditEvent]) -> Option<RunProviderCacheUsage> {
    let mut usage = ProviderCacheUsage {
        read_input_tokens: 0,
        creation_input_tokens: 0,
    };
    let mut saw_usage = false;

    for event in events
        .iter()
        .filter(|event| event.kind == "provider_round_completed")
    {
        let Some(cache_usage) = event.data.get("provider_cache_usage") else {
            continue;
        };
        if cache_usage.is_null() {
            continue;
        }
        let read_input_tokens = cache_usage
            .get("read_input_tokens")
            .and_then(|value| value.as_u64())
            .unwrap_or(0);
        let creation_input_tokens = cache_usage
            .get("creation_input_tokens")
            .and_then(|value| value.as_u64())
            .unwrap_or(0);
        saw_usage = true;
        usage.read_input_tokens = usage.read_input_tokens.saturating_add(read_input_tokens);
        usage.creation_input_tokens = usage
            .creation_input_tokens
            .saturating_add(creation_input_tokens);
    }

    if !saw_usage {
        return None;
    }

    let cacheable_input_tokens = usage
        .read_input_tokens
        .saturating_add(usage.creation_input_tokens);
    let hit_rate = if cacheable_input_tokens == 0 {
        None
    } else {
        Some(usage.read_input_tokens as f64 / cacheable_input_tokens as f64)
    };

    Some(RunProviderCacheUsage {
        read_input_tokens: usage.read_input_tokens,
        creation_input_tokens: usage.creation_input_tokens,
        cacheable_input_tokens,
        hit_rate,
    })
}

#[cfg(test)]
mod tests {
    use std::{path::Path, sync::Arc};

    use chrono::Utc;
    use serde_json::json;
    use tempfile::tempdir;

    use crate::{
        context::ContextConfig,
        provider::test_support::ScriptedAgentProvider,
        runtime::InitialWorkspaceBinding,
        types::{AgentState, AuditEvent, TaskKind},
    };

    use super::*;

    fn test_runtime(data_dir: &Path) -> Result<RuntimeHandle> {
        RuntimeHandle::new(
            "default",
            data_dir.to_path_buf(),
            InitialWorkspaceBinding::Detached,
            "http://localhost".into(),
            Arc::new(ScriptedAgentProvider::new(Vec::new())),
            "default".into(),
            ContextConfig::default(),
        )
    }

    #[test]
    fn render_text_uses_compact_model_labels_without_changing_response_identity() {
        let requested_model = ModelRouteRef::parse("openai@default/gpt-5.4").unwrap();
        let active_model = ModelRouteRef::parse("volcengine@plan/glm-5.2").unwrap();
        let response = RunOnceResponse {
            agent_id: "default".into(),
            final_status: RunFinalStatus::Completed,
            waiting_reason: None,
            final_text: String::new(),
            raw_final_text: None,
            sleep_reason: None,
            failure_artifact: None,
            tasks: Vec::new(),
            message_count: 0,
            changed_files: Vec::new(),
            token_usage: TokenUsage::new(0, 0),
            input_tokens: 0,
            output_tokens: 0,
            provider_cache_usage: None,
            requested_model: Some(requested_model.clone()),
            active_model: Some(active_model.clone()),
            fallback_active: true,
            model_rounds: 0,
            tool_calls: 0,
            shell_commands: 0,
            exec_command_items: 0,
            batched_exec_command_items: 0,
        };

        assert_eq!(
            response.render_text(),
            "Model: volcengine@plan/glm-5.2 (requested openai/gpt-5.4)"
        );
        assert_eq!(
            response.requested_model.unwrap().as_string(),
            "openai@default/gpt-5.4"
        );
        assert_eq!(
            response.active_model.unwrap().as_string(),
            "volcengine@plan/glm-5.2"
        );
    }

    #[tokio::test]
    async fn poll_view_keeps_runtime_error_visible_after_many_events() -> Result<()> {
        let dir = tempdir()?;
        let runtime = test_runtime(dir.path())?;
        runtime
            .quiesce_context_resource_observer_task_for_test()
            .await?;
        runtime.prepare_run_read_sources_for_test().await?;
        let sessions = runtime.begin_run_birth_sessions().await?;

        runtime.append_audit_event("runtime_error", json!({}))?;
        for index in 0..129 {
            runtime.append_audit_event("state_changed", json!({"index":index}))?;
        }

        runtime.prepare_run_read_sources_for_test().await?;
        let view = runtime.capture_run_poll_read(&sessions, None).await?;
        assert!(view.poll.runtime_error);
        Ok(())
    }

    #[tokio::test]
    async fn poll_view_keeps_early_task_ids_visible_after_many_task_updates() -> Result<()> {
        let dir = tempdir()?;
        let runtime = test_runtime(dir.path())?;
        runtime
            .quiesce_context_resource_observer_task_for_test()
            .await?;
        runtime.prepare_run_read_sources_for_test().await?;
        let sessions = runtime.begin_run_birth_sessions().await?;

        crate::runtime::tests::support::persist_task_transition(
            &runtime,
            &task_record("early-task"),
            "task_running",
        )
        .await?;
        for index in 0..129 {
            crate::runtime::tests::support::persist_task_transition(
                &runtime,
                &task_record(format!("later-task-{index}")),
                "task_running",
            )
            .await?;
        }

        runtime.prepare_run_read_sources_for_test().await?;
        let view = runtime.capture_run_poll_read(&sessions, None).await?;
        assert!(view.active_task_ids.iter().any(|id| id == "early-task"));
        Ok(())
    }

    fn task_record(id: impl Into<String>) -> TaskRecord {
        TaskRecord {
            id: id.into(),
            agent_id: "default".into(),
            kind: TaskKind::CommandTask,
            status: TaskStatus::Running,
            created_at: Utc::now(),
            updated_at: Utc::now(),
            parent_message_id: None,
            work_item_id: None,
            summary: None,
            detail: None,
            recovery: None,
        }
    }

    #[test]
    fn extract_patch_files_includes_move_source_and_destination() {
        let files = extract_patch_files(
            "diff --git a/src/old.rs b/src/new.rs\nrename from src/old.rs\nrename to src/new.rs\n--- a/src/old.rs\n+++ b/src/new.rs\n@@ -1,1 +1,1 @@\n-old\n+new\n",
        );
        assert_eq!(files, vec!["src/old.rs", "src/new.rs"]);
    }

    #[test]
    fn changed_files_from_tools_prefers_patch_input_and_normalizes_paths() {
        let workspace_root = Path::new("/tmp/workspace");
        let tool = ToolExecutionRecord {
            id: "tool-1".into(),
            agent_id: "default".into(),
            work_item_id: None,
            turn_index: 0,
            turn_id: None,
            tool_name: "ApplyPatch".into(),
            created_at: Utc::now(),
            completed_at: None,
            duration_ms: 0,
            authority_class: AuthorityClass::OperatorInstruction,
            status: ToolExecutionStatus::Success,
            input: json!({
                "patch": "diff --git a/notes/result.txt b/notes/final.txt\nrename from notes/result.txt\nrename to notes/final.txt\n--- a/notes/result.txt\n+++ b/notes/final.txt\n@@ -1,1 +1,1 @@\n-old\n+new\n"
            }),
            output: json!({
                "envelope": {
                    "result": {
                        "changed_paths": [
                            "/tmp/workspace/notes/result.txt",
                            "/tmp/workspace/notes/final.txt"
                        ]
                    }
                }
            }),
            summary: "patched".into(),
            invocation_surface: None,
        };

        let changed = changed_files_from_tools(&[tool], workspace_root);
        assert_eq!(changed, vec!["notes/result.txt", "notes/final.txt"]);
    }

    #[test]
    fn exec_command_task_id_reads_promoted_task_handle() {
        let tool = ToolExecutionRecord {
            id: "tool-command".into(),
            agent_id: "default".into(),
            work_item_id: None,
            turn_index: 0,
            turn_id: None,
            tool_name: "ExecCommand".into(),
            created_at: Utc::now(),
            completed_at: None,
            duration_ms: 0,
            authority_class: AuthorityClass::OperatorInstruction,
            status: ToolExecutionStatus::Success,
            input: json!({}),
            output: json!({
                "envelope": {
                    "result": {
                        "disposition": "promoted_to_task",
                        "task_handle": {
                            "task_id": "task-promoted",
                            "kind": "command_task",
                            "status": "running"
                        }
                    }
                }
            }),
            summary: "command promoted".into(),
            invocation_surface: None,
        };

        assert_eq!(exec_command_task_id(&tool), Some("task-promoted"));
    }

    #[test]
    fn exec_command_task_id_reads_current_result_shape() {
        let tool = ToolExecutionRecord {
            id: "tool-command".into(),
            agent_id: "default".into(),
            work_item_id: None,
            turn_index: 0,
            turn_id: None,
            tool_name: "ExecCommand".into(),
            created_at: Utc::now(),
            completed_at: None,
            duration_ms: 0,
            authority_class: AuthorityClass::OperatorInstruction,
            status: ToolExecutionStatus::Success,
            input: json!({}),
            output: json!({
                "result": {
                    "disposition": "promoted_to_task",
                    "task_handle": {
                        "task_id": "task-promoted",
                        "kind": "command_task",
                        "status": "running"
                    }
                }
            }),
            summary: "command promoted".into(),
            invocation_surface: None,
        };

        assert_eq!(exec_command_task_id(&tool), Some("task-promoted"));
    }

    #[test]
    fn exec_command_event_task_id_reads_tool_executed_task_handle() {
        let event = AuditEvent::legacy(
            "tool_executed",
            json!({
                "tool_name": "ExecCommand",
                "status": "success",
                "task_handle": {
                    "task_id": "task-promoted",
                    "task_kind": "command_task",
                    "status": "running"
                }
            }),
        );

        assert_eq!(exec_command_event_task_id(&event), Some("task-promoted"));
    }

    #[test]
    fn batched_exec_command_items_counts_batch_result_items() {
        let tool = ToolExecutionRecord {
            id: "tool-batch".into(),
            agent_id: "default".into(),
            work_item_id: None,
            turn_index: 0,
            turn_id: None,
            tool_name: "ExecCommandBatch".into(),
            created_at: Utc::now(),
            completed_at: None,
            duration_ms: 0,
            authority_class: AuthorityClass::OperatorInstruction,
            status: ToolExecutionStatus::Success,
            input: json!({}),
            output: json!({
                "envelope": {
                    "result": {
                        "item_count": 4,
                        "completed_count": 2,
                        "failed_count": 1,
                        "rejected_count": 1,
                        "skipped_count": 0
                    }
                }
            }),
            summary: "batch".into(),
            invocation_surface: None,
        };

        assert_eq!(batched_exec_command_items(&[tool]), 3);
    }

    #[test]
    fn aggregate_provider_cache_usage_sums_round_cache_tokens() {
        let events = vec![
            AuditEvent::legacy(
                "provider_round_completed",
                json!({
                    "provider_cache_usage": {
                        "read_input_tokens": 300,
                        "creation_input_tokens": 100
                    }
                }),
            ),
            AuditEvent::legacy(
                "provider_round_completed",
                json!({
                    "provider_cache_usage": {
                        "read_input_tokens": 200,
                        "creation_input_tokens": 400
                    }
                }),
            ),
            AuditEvent::legacy("state_changed", json!({})),
        ];

        let usage = aggregate_provider_cache_usage(&events).expect("cache usage");

        assert_eq!(usage.read_input_tokens, 500);
        assert_eq!(usage.creation_input_tokens, 500);
        assert_eq!(usage.cacheable_input_tokens, 1000);
        assert_eq!(usage.hit_rate, Some(0.5));
    }
}
