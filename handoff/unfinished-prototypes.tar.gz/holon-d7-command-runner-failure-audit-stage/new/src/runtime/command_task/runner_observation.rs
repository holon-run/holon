//! Immutable original admission only; no mutable producer or process responsibility escapes.
use super::*;
use crate::runtime::{
    current_read_facts::CurrentReadError,
    input_evidence_budget::borrowed_json_material,
    resident_input_evidence::InputEvidenceScope,
};

#[derive(Debug)]
pub(crate) struct OriginalCommandRunnerObservation {
    fact: Arc<QualifiedTaskFact>,
    owner_epoch: u64,
    usage: (usize, usize),
    _source_view: Arc<BudgetViewGuard>,
    _source_owned: Arc<BudgetViewGuard>,
    _address_material: Arc<BudgetViewGuard>,
    _retained: Vec<Arc<BudgetViewGuard>>,
    _metadata: Arc<BudgetViewGuard>,
}
impl OriginalCommandTaskProducer {
    pub(in crate::runtime) async fn runner_observation(
        &self,
        agent_id: &str,
        incarnation: u64,
        owner_epoch: u64,
        ledger: &InputEvidenceBudgetLedger,
    ) -> Result<Arc<OriginalCommandRunnerObservation>> {
        ensure!(!self.is_durable_finished(), "Command producer already acknowledged");
        // The original view proves the actual registration/lease. Neither its
        // lock nor the lease is retained by the root-free audit observation.
        let pending = self.prepared.lock().await;
        let view = self.source_view()?;
        let terminal = self.terminal.lock().map_err(|_| anyhow::anyhow!("Command terminal source poisoned"))?;
        let notifications = self.notifications.lock().map_err(|_| anyhow::anyhow!("Command notifications poisoned"))?;
        let prepared_material = pending.as_ref().map(|prepared| prepared.original_command_runner_material()).transpose()?;
        let prepared_guards = prepared_material.as_ref().map_or(&[][..], |(_, guards)| *guards);
        let guard_slots = prepared_guards.len().checked_add(usize::from(terminal.is_some()))
            .and_then(|n| n.checked_add(usize::from(notifications.is_some())))
            .context("Command runner retained slots overflow")?;
        let metadata_bytes = u64::try_from(guard_slots)?.checked_mul(
            u64::try_from(std::mem::size_of::<Arc<BudgetViewGuard>>())?.checked_add(256)
                .context("Command runner slot size overflow")?)
            .and_then(|n| n.checked_add(8192)).context("Command runner metadata overflow")?;
        let source = view.source.as_ref().expect("sealed original source");
        let scope = &source.fact.locator.scope;
        ensure!(
            scope.agent_id == agent_id
                && scope.identity_incarnation == incarnation
                && self.address.owner_epoch == owner_epoch,
            "Command runner observation crossed its original owner"
        );
        source.fact.validate(scope)?;
        ensure!(matches!(&source.fact.fact, CanonicalTaskFact::Task(t) if t.kind == TaskKind::CommandTask),
            "Command runner observation selected another family");
        for guard in [&source._owned, &source._view, &self._address_material] {
            guard.validate_owned_material_binding(scope, ledger, guard.owned_material_bytes()?)?;
        }
        let (encoded, nodes) = borrowed_json_material(source.fact.as_ref())?;
        // Existing monitor/error Task DTOs and the admitted fact remain live.
        // Share their original allocation guards; add the native floor without
        // registering the shared Task body a second time.
        let records = nodes.checked_mul(4).and_then(|n| n.checked_add(128))
            .context("Command runner source native records overflow")?;
        let native = encoded.checked_mul(4)
            .and_then(|n| n.checked_add(u64::try_from(records).ok()?.checked_mul(256)?))
            .context("Command runner source native bytes overflow")?;
        let mut extra_bytes = 0u64;
        let mut extra_records = guard_slots;
        if let Some(frozen) = terminal.as_ref() {
            frozen._material.validate_owned_material_binding(scope, ledger, frozen._material.owned_material_bytes()?)?;
            let (encoded, nodes) = borrowed_json_material(&(&frozen.task, &frozen.message, &frozen.nonce, frozen.at))?;
            let floor = encoded.checked_add(u64::try_from(nodes)?.checked_mul(256)
                .context("Command runner terminal native overflow")?)
                .context("Command runner terminal bytes overflow")?;
            extra_bytes = extra_bytes.checked_add(floor.max(frozen._material.owned_material_bytes()?))
                .context("Command runner terminal prior overflow")?;
            extra_records = extra_records.checked_add(nodes).context("Command runner terminal records overflow")?;
        }
        if let Some(notification) = notifications.as_ref() {
            notification._material.validate_owned_material_binding(scope, ledger, notification._material.owned_material_bytes()?)?;
            let (encoded, nodes) = borrowed_json_material(&notification.receipt)?;
            let floor = encoded.checked_add(u64::try_from(nodes)?.checked_mul(256)
                .context("Command runner receipt native overflow")?)
                .context("Command runner receipt bytes overflow")?;
            extra_bytes = extra_bytes.checked_add(floor.max(notification._material.owned_material_bytes()?))
                .context("Command runner receipt prior overflow")?;
            extra_records = extra_records.checked_add(nodes).context("Command runner receipt records overflow")?;
        }
        if let Some(((encoded, nodes), guards)) = &prepared_material {
            let mut owned = 0u64;
            for (index, guard) in guards.iter().enumerate() {
                guard.validate_owned_material_binding(scope, ledger, guard.owned_material_bytes()?)?;
                if !guards[..index].iter().any(|other| Arc::ptr_eq(other, guard)) {
                    owned = owned.checked_add(guard.owned_material_bytes()?).context("Command runner prepared guards overflow")?;
                }
            }
            let floor = encoded.checked_add(u64::try_from(*nodes)?.checked_mul(256)
                .context("Command runner prepared native overflow")?)
                .context("Command runner prepared bytes overflow")?;
            extra_bytes = extra_bytes.checked_add(floor.max(owned)).context("Command runner prepared prior overflow")?;
            extra_records = extra_records.checked_add(*nodes).context("Command runner prepared records overflow")?;
        }
        let address_bytes = self._address_material.owned_material_bytes()?;
        let bytes = native.max(source._owned.owned_material_bytes()?)
            .checked_add(source._view.owned_material_bytes()?)
            .and_then(|n| n.checked_add(address_bytes))
            .and_then(|n| n.checked_add(extra_bytes))
            .and_then(|n| n.checked_add(metadata_bytes))
            .context("Command runner source combined bytes overflow")?;
        let records = records.checked_add(extra_records).and_then(|n| n.checked_add(32))
            .context("Command runner source slots overflow")?;
        let limits = ledger.limits();
        ensure!(
            bytes <= limits.history_per_agent_bytes.checked_add(limits.pending_per_agent_bytes)
                .context("Command runner source allowance overflow")?.min(64 * 1024 * 1024)
                && records <= usize::try_from(limits.record_limit)?.min(65536),
            CurrentReadError::ResourceExhausted
        );
        let metadata = ledger.register_host_owned_bytes(
            InputMemoryCategory::Candidate,
            OwnedBytesEstimate { payload_bytes: 0, metadata_estimate_bytes: metadata_bytes },
        )?;
        metadata.validate_host_owned_material_binding(ledger, metadata_bytes)?;
        let mut retained = Vec::with_capacity(guard_slots);
        retained.extend(terminal.as_ref().map(|frozen| frozen._material.clone()));
        retained.extend(notifications.as_ref().map(|notification| notification._material.clone()));
        retained.extend(prepared_guards.iter().cloned());
        Ok(Arc::new(OriginalCommandRunnerObservation {
            fact: source.fact.clone(),
            owner_epoch,
            usage: (usize::try_from(bytes)?, records),
            _source_view: source._view.clone(),
            _source_owned: source._owned.clone(),
            _address_material: self._address_material.clone(),
            _retained: retained,
            _metadata: metadata,
        }))
    }
}
impl OriginalCommandRunnerObservation {
    pub(in crate::runtime) fn scope(&self) -> &InputEvidenceScope { &self.fact.locator.scope }
    pub(in crate::runtime) fn task_id(&self) -> &str {
        let CanonicalTaskFact::Task(task) = &self.fact.fact else { unreachable!() };
        &task.id
    }
    pub(in crate::runtime) fn material_estimate(&self) -> (usize, usize) { self.usage }
    pub(in crate::runtime) fn validate_accounting(
        &self, scope: &InputEvidenceScope, epoch: u64, ledger: &InputEvidenceBudgetLedger,
    ) -> Result<()> {
        ensure!(self.scope() == scope && self.owner_epoch == epoch,
            "Command runner observation scope or owner changed");
        self.fact.validate(scope)?;
        for guard in [&self._source_view, &self._source_owned, &self._address_material] {
            guard.validate_owned_material_binding(scope, ledger, guard.owned_material_bytes()?)?;
        }
        self._metadata.validate_host_owned_material_binding(ledger, metadata_bytes)?;
        let mut retained = Vec::with_capacity(guard_slots);
        retained.extend(terminal.as_ref().map(|frozen| frozen._material.clone()));
        retained.extend(notifications.as_ref().map(|notification| notification._material.clone()));
        retained.extend(prepared_guards.iter().cloned());
        Ok(())
    }
    pub(in crate::runtime) fn validate_original_generation(&self, actual: &TaskRecord) -> Result<()> {
        let CanonicalTaskFact::Task(before) = &self.fact.fact else { unreachable!() };
        ensure!(
            actual.id == before.id && actual.agent_id == before.agent_id
                && actual.kind == before.kind && actual.created_at == before.created_at
                && actual.work_item_id == before.work_item_id
                && super::super::super::task_generation::same_task_rejoin_generation(actual, before),
            "Command runner target crossed original admitted Task generation"
        );
        Ok(())
    }
}
