// The production monitor reaches this audit only after its original terminal attempt fails.
fn runner_audits(runtime: &RuntimeHandle) -> Result<Vec<crate::types::AuditEvent>> {
    let connection = runtime.runtime_db().connection()?;
    let mut statement = connection.prepare(
        "SELECT data_json FROM audit_events WHERE kind='command_task_runner_failed' ORDER BY event_seq",
    )?;
    let rows = statement.query_map([], |r| r.get::<_, String>(0))?;
    rows.map(|row| Ok(serde_json::from_str(&row?)?)).collect()
}
#[tokio::test]
async fn actual_runner_failure_audit_keeps_original_terminal_retry_and_result_after_closing() -> Result<()> {
    for reject_audit in [false, true] {
        let (_home, _workspace, runtime, task, process, lease, source) =
            accepted_original_producer_fixture().await?;
        runtime.quiesce_context_resource_observer_task_for_test().await?;
        if reject_audit {
            runtime.runtime_db().connection()?.execute_batch(
                "CREATE TRIGGER reject_original_runner_audit BEFORE INSERT ON audit_events
                 WHEN NEW.kind='command_task_runner_failed'
                 BEGIN SELECT RAISE(ABORT,'original runner audit rollback'); END;",
            )?;
        }
        // Frozen terminal consumes this fault once. Its genuine failed attempt
        // reaches the outer monitor; the same capsule then retries unchanged.
        runtime.inject_transition_fault(crate::runtime_db::transitions::TransitionFaultPoint::BeforeCommit);
        runtime.close_mutation_admission();
        *process.status.lock().await = Some(RunningProcessExitStatus::new(Some(0), None));
        await_original_durable_terminal(&source).await?;
        lease.join().await?;
        let actual = runtime.runtime_db().tasks().latest(&task.id)?.unwrap();
        assert_eq!(actual.status, TaskStatus::Completed, "original frozen outcome was replaced");
        let receipt = original_terminal_receipt(&runtime, &source)?.context("original terminal receipt missing")?;
        use crate::runtime_db::{command_task_terminal::CommandTaskTerminalResult,
            input_mutation_receipts::InputMutationResult};
        let InputMutationResult::CommandTaskTerminal { ack } = &receipt.outcome.result else { panic!("wrong original receipt") };
        let CommandTaskTerminalResult::Delivered { message_id } = &ack.result else { panic!("original result lost") };
        let result = runtime.runtime_db().transaction(|tx| {
            crate::runtime_db::evidence::committed_message_tx(tx, &task.agent_id, message_id)
        })?;
        assert_eq!(result.task_id.as_deref(), Some(task.id.as_str()));
        assert_eq!(result.metadata.as_ref().unwrap()["task_status"], "completed");
        assert_eq!(runtime.runtime_db().connection()?.query_row(
            "SELECT COUNT(*) FROM messages WHERE evidence_id=?1", [message_id], |r| r.get::<_, usize>(0))?, 1);
        let audits = runner_audits(&runtime)?;
        assert_eq!(audits.len(), usize::from(!reject_audit));
        if let Some(event) = audits.first() {
            assert_eq!(event.data["task_id"], task.id);
            assert!(event.data["error"].as_str().unwrap().contains("BeforeCommit"));
            assert_eq!(event.data.as_object().unwrap().len(), 2);
            assert_eq!(runtime.runtime_db().connection()?.query_row(
                "SELECT COUNT(*) FROM current_read_members WHERE family='event' AND record_id=?1", [&event.id], |r| r.get::<_, usize>(0))?, 1);
            assert_eq!(runtime.runtime_db().connection()?.query_row(
                "SELECT COUNT(*) FROM current_event_native_births WHERE event_id=?1", [&event.id], |r| r.get::<_, usize>(0))?, 1);
            let terminal_seq: u64 = runtime.runtime_db().connection()?.query_row(
                "SELECT MIN(event_seq) FROM audit_events WHERE kind='command_task_terminal_persisted'
                 AND json_extract(data_json,'$.data.task_id')=?1", [&task.id], |r| r.get(0))?;
            assert!(event.event_seq < terminal_seq);
        }
        assert!(source.is_durable_finished());
        assert_eq!(source.address().admitted.key.id, task.id);
        assert_eq!(process.stop_signals.lock().await.len(), 0);
    }
    Ok(())
}
#[tokio::test]
async fn original_runner_observation_keeps_native_prior_and_rejects_foreign_or_changed_generation() -> Result<()> {
    let (_home, _workspace, runtime, task, process, lease, source) =
        accepted_original_producer_fixture().await?;
    runtime.quiesce_context_resource_observer_task_for_test().await?;
    let ledger = &runtime.inner.input_evidence_budget;
    let baseline = ledger.report()?.observed_bytes;
    let observation = source.runner_observation(runtime.instance_agent_id(),
        runtime.instance_incarnation(), runtime.instance_owner_epoch(), ledger).await?;
    assert!(observation.material_estimate().0 > source.runner_material()?.owned_material_bytes()? as usize);
    let foreign = super::super::input_evidence_budget::InputEvidenceBudgetLedger::new(Default::default())?;
    assert!(observation.validate_accounting(observation.scope(), runtime.instance_owner_epoch(), &foreign).is_err());
    assert!(observation.validate_accounting(observation.scope(), runtime.instance_owner_epoch()+1, ledger).is_err());
    assert_eq!(foreign.report()?.observed_bytes, 0);
    let actual = runtime.runtime_db().tasks().latest(&task.id)?.unwrap();
    observation.validate_original_generation(&actual)?;
    let mut changed = actual.clone();
    changed.created_at += chrono::Duration::milliseconds(1);
    assert!(observation.validate_original_generation(&changed).is_err());
    changed = actual.clone();
    let mut detail = changed.detail.take().unwrap_or_else(|| json!({}));
    detail.as_object_mut().unwrap().insert("rejoin_obligation_id".into(), json!(task.id));
    detail.as_object_mut().unwrap().insert("rejoin_generation".into(), json!(7));
    changed.detail = Some(detail);
    assert!(observation.validate_original_generation(&changed).is_err());
    let weak = Arc::downgrade(&observation);
    drop(observation);
    assert!(weak.upgrade().is_none());
    assert_eq!(ledger.report()?.observed_bytes, baseline);
    let huge = anyhow::anyhow!("{}", "x".repeat(9 * 1024 * 1024));
    let before = runner_audits(&runtime)?;
    let error = runtime.record_original_command_runner_failure(&source, &huge).await.err()
        .context("huge derived runner error unexpectedly fit")?;
    assert!(error.downcast_ref::<super::super::current_read_facts::CurrentReadError>().is_some());
    assert_eq!(runner_audits(&runtime)?, before);
    assert_eq!(ledger.report()?.observed_bytes, baseline);
    assert_eq!(runtime.runtime_db().tasks().latest(&task.id)?.unwrap(), actual);
    *process.status.lock().await = Some(RunningProcessExitStatus::new(Some(0), None));
    await_original_durable_terminal(&source).await?;
    lease.join().await?;
    Ok(())
}
