//! A runner failure observes only its admitted generation; terminal duty remains separate.
use super::*;
use crate::runtime::{
    command_task::OriginalCommandTaskProducer,
    resident_task::{CanonicalTaskFact, TaskCaptureRequest, TaskFamily, TaskKey},
};

struct DisplayLength(usize);
impl std::fmt::Write for DisplayLength {
    fn write_str(&mut self, value: &str) -> std::fmt::Result {
        self.0 = self.0.checked_add(value.len()).ok_or(std::fmt::Error)?;
        Ok(())
    }
}
struct BoundedDisplay {
    value: String,
    limit: usize,
}
impl std::fmt::Write for BoundedDisplay {
    fn write_str(&mut self, value: &str) -> std::fmt::Result {
        if self.value.len().checked_add(value.len()).ok_or(std::fmt::Error)? > self.limit {
            return Err(std::fmt::Error);
        }
        self.value.push_str(value);
        Ok(())
    }
}
impl RuntimeHandle {
    pub(in crate::runtime) async fn record_original_command_runner_failure(
        &self,
        producer: &Arc<OriginalCommandTaskProducer>,
        error: &anyhow::Error,
    ) -> Result<()> {
        use std::fmt::Write;
        let ledger = &self.inner.input_evidence_budget;
        let observation = producer.runner_observation(
            self.instance_agent_id(), self.instance_incarnation(),
            self.instance_owner_epoch(), ledger,
        ).await?;
        let mut length = DisplayLength(0);
        write!(&mut length, "{error}").context("Command runner error length overflow")?;
        // UTF-8 JSON escaping is at most six bytes for each original byte.
        // Count the original Display without allocating its first String.
        let escaped = u64::try_from(length.0)?.checked_mul(6)
            .context("Command runner error escaping overflow")?;
        let material = self.prepare_original_runtime_observation_material_with_prior(
            OriginalLifecycleNoopKind::CommandRunnerFailed,
            &(observation.task_id(), ""), escaped, Some(observation.clone()),
        )?;
        let prior = (
            material.guard.owned_material_bytes()?.checked_add(u64::try_from(observation.material_estimate().0)?)
                .context("Command runner selected prior bytes overflow")?,
            material.records.checked_add(observation.material_estimate().1)
                .context("Command runner selected prior records overflow")?,
        );
        let mut owner = self.begin_mutation().await?;
        anyhow::ensure!(owner.reservations[owner.primary_index].owner_epoch() == self.instance_owner_epoch(),
            "Command runner owner changed while waiting");
        // Only an existing qualified Task on the held publication can supply
        // this observation. No canonical Task write/OCC or Stop grant is added.
        {
            let root = owner.capture_published_root()?;
            root.active_identity()?;
            let limits = ledger.limits();
            let bytes = limits.history_per_agent_bytes.checked_add(limits.pending_per_agent_bytes)
                .context("Command runner allowance overflow")?.min(64 * 1024 * 1024);
            let request = TaskCaptureRequest {
                include_active: false,
                include_unsettled: false,
                terminal_limit: 0,
                required_keys: std::iter::once(TaskKey::new(TaskFamily::Task, observation.task_id())).collect(),
            };
            let (selected, selected_material) = root.tasks.as_ref()
                .context(crate::runtime_db::task_snapshot::TaskSnapshotError::NeedsPreparation(
                    TaskKey::new(TaskFamily::Task, observation.task_id())))?
                .capture_with_material(&request, ledger,
                    (usize::try_from(bytes)?, usize::try_from(limits.record_limit)?.min(65536)),
                    prior, None)?;
            let CanonicalTaskFact::Task(actual) = &selected.records.iter().find(|record| record.locator.key.family == TaskFamily::Task
                && record.locator.key.id == observation.task_id())
                .context("Command runner qualified Task absent")?.fact else {
                    anyhow::bail!("Command runner qualified target has another family")
                };
            observation.validate_original_generation(actual)?;
            // All selected metadata/records and their scratch guard leave this
            // synchronous phase before the Audit decoder begins.
            drop((selected, selected_material, root));
        }
        let mut display = BoundedDisplay { value: String::with_capacity(length.0), limit: length.0 };
        write!(&mut display, "{error}").context("Command runner error changed while rendering")?;
        let audit = material.freeze(self, AuditEvent::legacy(
            "command_task_runner_failed",
            serde_json::json!({ "task_id":observation.task_id(), "error":display.value }),
        ))?;
        owner.append_held_runtime_observation_audit(audit).await
    }
}
