# Command runner failure WIP checkpoint

状态：未冻结、未独立审阅、未 parse/编译/native、未应用。不能作为交付。Root 要求停止新增功能，优先当前 Result 失败与正式 D7 检查点，本 WIP 保存后等待后续安排。

目录 `new/` 保存当前增量草稿，`base/` 是 readonly actual81（包括原 d065）捕获。原 monitor 只有在 `run_command_task` 整体 Err 后才尝试 runner 审计；内部 process error 会先停止/等待，并提交原 terminal。计划保留 Audit Err 忽略后 original frozen terminal 继续，无 Task OCC/Stop/NoState 新权限。

当前草稿将 fixed runtime-observation family 加 `CommandRunnerFailed`；有限 root-free observation 仅原 admitted qualified fact/实际 guards/usage，不保存 mutable producer 或 Root。首次 error String 前流式测 Display 与 JSON escape 上界；先联合 retained producer material，再 held published Task generation 观察，释放选择 scratch 后进入原 Audit wholeACK。已经补草稿读取现有 Frozen/Prepared/notifications 成本，但其完整资源/lifetime正确性尚未独立核完，不可推为 closed。

两个新增测试函数仍是未验证草稿：真实原 terminal 一次 BeforeCommit 故障→outer runner audit→same original capsule retry，含 Audit SQL rollback 与 Closing；root-free observation native prior/foreign ledger/generation和大 error 首 derived-copy拒绝。原 process/terminal 时序保持目标尚待实际编译/native证据。

原 generic begin_mutation acquisition/canonical State/native/outer request prior/facts/Root copied State 与整个 D7 required 清单继续有效，不能因本 WIP 停止而删债或缩验收。
