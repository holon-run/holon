//! Runtime database facade: connection management, write queue, and domain repositories.
//!
//! This module is split into submodules by storage responsibility:
//! - [`types`]: public types (repository handles, index outbox, storage domain).
//! - [`write_queue`]: background writer task and write queue.
//! - [`connection`]: SQLite connection setup, retry, and file locking.
//! - [`migrations`]: schema migrations.
//! - [`storage_domain`]: storage domain checkpoint helpers.
//! - [`evidence`]: evidence insertion and query types.
//! - [`repositories`]: domain repository implementations.
//! - [`index_outbox`]: runtime index outbox repository.

pub mod agent_message_delivery;
pub mod agent_relations;
pub mod audit;
pub mod authentication;
pub(crate) mod bootstrap_inputs;
pub mod brief_publication_repair;
pub mod connection;
pub mod content_reports;
pub(crate) mod context_inputs;
pub(crate) mod mutation_canonical_material;
pub(crate) mod control_transition;
pub mod conversation;
pub(crate) mod current_read_snapshot;
pub(crate) mod cold_child_domains;
pub mod destructive_operations;
pub(crate) mod dispatch_memory;
pub(crate) mod episode_memory;
pub(crate) mod episode_snapshot;
pub mod evidence;
pub(crate) mod input_evidence_snapshot;
#[cfg(test)]
pub(crate) use input_evidence_snapshot::read_material::probe_original_report_input_prior_for_test;
pub(crate) mod input_evidence_writes;
pub(crate) mod input_mutation_receipts;
pub(crate) mod input_preparation;
pub(crate) mod input_recovery_install;
mod legacy_scheduler_wire;
pub mod migrations;
pub mod persistence;
pub(crate) mod prepared_input_evidence;
pub(crate) mod reclamation;
pub(crate) mod reclamation_reminders;
pub mod repositories;
pub mod retention;
pub mod retired_scheduler_cleanup;
pub(crate) mod startup_ended_memory;
pub mod storage_domain;
pub(crate) mod task_result_settlement;
mod task_input_queue;
pub(crate) mod transitions;
pub mod turn_settlement_repair;
pub use input_evidence_snapshot::maintenance::{
    NeedsOfflineInputMaintenance, OfflineInputMaintenance,
};
pub(crate) mod child_task_terminal;
pub(crate) mod command_task_terminal;
pub(crate) mod scheduling_snapshot;
pub(crate) mod task_recovery;
pub(crate) mod task_snapshot;
pub(crate) mod task_status_metadata;
pub(crate) mod task_stop;
pub mod types;
pub mod unread;
pub(crate) mod work_item_recall;
pub(crate) mod work_snapshot;
pub mod write_queue;

pub mod observer_sync;

mod index_outbox;

// Re-export public types that are referenced as `crate::runtime_db::Type`.
pub use crate::runtime_db::audit::{
    AgentBriefIntegrityAudit, BriefIntegrityAudit, BriefIntegrityCategory, BriefIntegrityCounts,
    ProjectionEffectInventoryGroup, ProjectionEffectsAudit, RuntimeDbAuditBaseline,
    RuntimeDbAuditCheck, RuntimeDbAuditDatabase, RuntimeDbAuditOptions, RuntimeDbAuditReport,
    ViolationSplit,
};
pub use crate::runtime_db::authentication::AuthenticationRepository;
pub use crate::runtime_db::brief_publication_repair::{
    WaitFinalBriefPublicationRepairDiagnostic, WaitFinalBriefPublicationRepairPhase,
    WaitFinalBriefPublicationRepairPlanStatus, WaitFinalBriefPublicationRepairProgress,
    WaitFinalBriefPublicationRepairReport,
};
pub use crate::runtime_db::destructive_operations::{
    DestructiveOperationPhase, DestructiveOperationRecord, DestructiveOperationRepository,
    PlannedDestructiveOperation,
};
pub use crate::runtime_db::evidence::{
    EvidenceKind, EvidencePayloadRow, EvidenceQuery, EvidenceRow,
};
pub use crate::runtime_db::index_outbox::{
    RuntimeIndexChange, RuntimeIndexOperation, RuntimeIndexOutboxRepository, RuntimeIndexOutboxRow,
};
pub use crate::runtime_db::observer_sync::{
    AgentEventRecoveryWindow, AgentRosterLatestBriefRow, AgentRosterRow, AgentRosterSnapshotRows,
};
pub(crate) use crate::runtime_db::persistence::retryable_state_transition_conflict;
pub use crate::runtime_db::persistence::{
    persistence_certainty, PersistenceCertainty, PersistenceFailure, PersistenceFailurePhase,
};
pub use crate::runtime_db::retention::{
    RuntimeDbCompactReport, RuntimeDbRetentionPolicy, RuntimeDbRetentionReport,
    RuntimeDbRetentionTableReport,
};
pub use crate::runtime_db::retired_scheduler_cleanup::{
    RetiredSchedulerCleanupBlocker, RetiredSchedulerCleanupBlockerKind,
    RetiredSchedulerCleanupInventory, RetiredSchedulerFallbackAction,
    RetiredSchedulerFallbackActionKind, RetiredSchedulerFallbackResult,
};
pub use crate::runtime_db::storage_domain::{ExpectedStorageDomain, StorageDomainSnapshot};
pub(crate) use crate::runtime_db::task_result_settlement::{
    TaskResultSettlementDisposition, TaskResultSettlementRecord,
};
pub use crate::runtime_db::turn_settlement_repair::{
    TurnSettlementRepairDiagnostic, TurnSettlementRepairPhase, TurnSettlementRepairProgress,
    TurnSettlementRepairReport,
};
pub use crate::runtime_db::types::{
    AgentBootstrapRepository, AgentCanonicalRelationRepository, AgentDeletionRepository,
    AgentIdentityRepository, AgentMessageDeliveryRepository, AgentStateRepository, AuditEventSink,
    ContentReportRepository, ContextEpisodeRepository, ConversationRepository, EvidenceRepository,
    ExecutionRootEntryRepository, ExternalTriggerRepository, MessageRepository,
    OperatorDeliveryRepository, OperatorNotificationRepository, OperatorTransportBindingRepository,
    QueueEntryRepository, TaskRepository, TimerCancel, TimerCancelResult, TimerFire,
    TimerFireResult, TimerRepository, TimerWakeRecord, TimerWakeRecoveryResult, TimerWakeStatus,
    TranscriptRepository, TurnRecordRepository, WaitConditionRepository,
    WorkItemContinuationRepository, WorkItemDelegationRepository, WorkItemRepository,
    WorkspaceEntryRepository, WorkspaceOccupancyRepository,
};
#[cfg(test)]
mod tests;

use std::{
    error::Error as StdError,
    fmt,
    fs::{self, File, OpenOptions},
    path::{Path, PathBuf},
    time::Duration,
};

use anyhow::{anyhow, bail, Context, Result};
use chrono::Utc;
use rusqlite::{Connection, OptionalExtension, Transaction};
use serde::{Deserialize, Serialize};

use crate::runtime_db::connection::{
    configure_new_database_auto_vacuum, configure_persistent_database, flock, open_connection,
    unlock, LockMode,
};
use crate::runtime_db::migrations::{
    apply_migration, apply_release_baseline, backfill_wait_condition_payload_columns,
    backfill_work_item_blocker_wait_provenance, backfill_work_item_recheck_columns,
    current_schema_version, ensure_migration_table, max_known_migration_version,
    AGENT_CANONICAL_RELATIONS_SCHEMA_VERSION, CONVERSATION_INPUT_ASSIGNMENT_REPAIR_NAME,
    CONVERSATION_INPUT_ASSIGNMENT_REPAIR_VERSION, MIGRATIONS, PUBLISHED_MIGRATION_FLOOR,
    RELEASE_BASELINE_TARGET, RETIRED_SCHEDULER_SCHEMA_PREDECESSOR,
};
use crate::runtime_db::storage_domain::{
    read_storage_domain_connection, upsert_storage_domain, upsert_storage_domain_checkpoint_json,
};
use crate::runtime_db::write_queue::{RuntimeDbWriteContext, RuntimeDbWriter};

pub(crate) const TASK_PAYLOAD_STRING_LIMIT: usize = 2048;
pub(crate) const TASK_PAYLOAD_ARRAY_LIMIT: usize = 64;
pub(crate) const EVIDENCE_PREVIEW_LIMIT: usize = 2048;
pub(crate) const CONTEXT_EPISODE_ANCHORS_DOMAIN: &str = "context_episode_anchors";
pub(crate) const RUNTIME_DB_BUSY_TIMEOUT: Duration = Duration::from_millis(30_000);
pub(crate) const RUNTIME_DB_TRANSACTION_RETRY_INITIAL_DELAY: Duration = Duration::from_millis(25);
pub(crate) const RUNTIME_DB_TRANSACTION_RETRY_MAX_DELAY: Duration = Duration::from_millis(1_000);
pub(crate) const RUNTIME_DB_BEGIN_RETRY_WARN_INTERVAL: Duration = Duration::from_secs(30);
pub(crate) const RUNTIME_DB_TRANSACTION_RETRY_WARN_INTERVAL: Duration = Duration::from_secs(30);
pub(crate) const RUNTIME_DB_APPEND_RETRY_MAX_DELAY: Duration = Duration::from_millis(5_000);
pub(crate) const RUNTIME_DB_WRITE_QUEUE_CAPACITY: usize = 1024;

#[derive(Debug)]
pub struct RuntimeDbRetryableError {
    operation: &'static str,
    path: PathBuf,
    source: String,
}

impl RuntimeDbRetryableError {
    pub(crate) fn new(operation: &'static str, path: &Path, source: impl fmt::Display) -> Self {
        Self {
            operation,
            path: path.to_path_buf(),
            source: source.to_string(),
        }
    }

    pub fn operation(&self) -> &'static str {
        self.operation
    }
}

impl fmt::Display for RuntimeDbRetryableError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            formatter,
            "retryable runtime db error while {} for {}: {}",
            self.operation,
            self.path.display(),
            self.source
        )
    }
}

impl StdError for RuntimeDbRetryableError {}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RuntimeDbProtectionError {
    path: PathBuf,
    evidence: String,
}

impl RuntimeDbProtectionError {
    pub(crate) fn new(path: &Path, evidence: impl Into<String>) -> Self {
        Self {
            path: path.to_path_buf(),
            evidence: evidence.into(),
        }
    }

    pub fn evidence(&self) -> &str {
        &self.evidence
    }
}

impl fmt::Display for RuntimeDbProtectionError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            formatter,
            "runtime database is quarantined after sidecar protection failed for {}: {}; preserve the database, WAL, SHM, and open-FD evidence, then restart or perform offline recovery",
            self.path.display(),
            self.evidence
        )
    }
}

impl StdError for RuntimeDbProtectionError {}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum RuntimeDbProtectionState {
    Starting,
    Protected,
    Unsupported,
    Quarantined,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct RuntimeDbProtectionStatus {
    pub state: RuntimeDbProtectionState,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub evidence: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ConversationInputAssignmentRollbackReport {
    pub apply: bool,
    pub eligible: bool,
    pub changed: bool,
    pub backup_verified: bool,
    pub database_path: PathBuf,
    pub current_version: i64,
    pub current_name: Option<String>,
    pub target_version: i64,
    pub target_name: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub backup_path: Option<PathBuf>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub reason: Option<String>,
}

impl RuntimeDbProtectionStatus {
    pub fn is_healthy(&self) -> bool {
        self.state != RuntimeDbProtectionState::Quarantined
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RuntimeStateTransitionConflict {
    domain: &'static str,
    record_id: String,
    code: &'static str,
    existing_status: String,
    incoming_status: String,
    expected_revision: Option<u64>,
    actual_revision: Option<u64>,
    retryable: bool,
}

impl RuntimeStateTransitionConflict {
    pub(crate) fn new(
        domain: &'static str,
        record_id: impl Into<String>,
        existing_status: impl Into<String>,
        incoming_status: impl Into<String>,
    ) -> Self {
        Self {
            domain,
            record_id: record_id.into(),
            code: "state_transition_conflict",
            existing_status: existing_status.into(),
            incoming_status: incoming_status.into(),
            expected_revision: None,
            actual_revision: None,
            retryable: false,
        }
    }

    pub(crate) fn revision(
        record_id: impl Into<String>,
        code: &'static str,
        expected_revision: Option<u64>,
        actual_revision: Option<u64>,
        retryable: bool,
    ) -> Self {
        Self {
            domain: "work_item",
            record_id: record_id.into(),
            code,
            existing_status: actual_revision
                .map_or_else(|| "missing".to_string(), |revision| revision.to_string()),
            incoming_status: expected_revision
                .map_or_else(|| "none".to_string(), |revision| revision.to_string()),
            expected_revision,
            actual_revision,
            retryable,
        }
    }

    pub(crate) fn concurrent_mutation(domain: &'static str, record_id: impl Into<String>) -> Self {
        Self {
            domain,
            record_id: record_id.into(),
            code: "revision_conflict",
            existing_status: "changed".into(),
            incoming_status: "expected_snapshot".into(),
            expected_revision: None,
            actual_revision: None,
            retryable: true,
        }
    }

    pub fn domain(&self) -> &'static str {
        self.domain
    }

    pub fn record_id(&self) -> &str {
        &self.record_id
    }

    pub fn code(&self) -> &'static str {
        self.code
    }

    pub fn existing_status(&self) -> &str {
        &self.existing_status
    }

    pub fn incoming_status(&self) -> &str {
        &self.incoming_status
    }

    pub fn expected_revision(&self) -> Option<u64> {
        self.expected_revision
    }

    pub fn actual_revision(&self) -> Option<u64> {
        self.actual_revision
    }

    pub fn retryable(&self) -> bool {
        self.retryable
    }
}

impl fmt::Display for RuntimeStateTransitionConflict {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        if self.expected_revision.is_some() || self.actual_revision.is_some() {
            write!(
                formatter,
                "{} for {} {}: expected revision {:?}, actual revision {:?}",
                self.code,
                self.domain,
                self.record_id,
                self.expected_revision,
                self.actual_revision
            )
        } else {
            write!(
                formatter,
                "conflicting {} transition for {}: {} -> {}",
                self.domain, self.record_id, self.existing_status, self.incoming_status
            )
        }
    }
}

impl StdError for RuntimeStateTransitionConflict {}

#[derive(Clone)]
pub struct RuntimeDb {
    path: PathBuf,
    lock_path: PathBuf,
    writer: RuntimeDbWriter,
    /// Unix millis of the last observer-sync read-side self-heal attempt.
    /// Throttles the heal so a failing capability gate does not re-run the
    /// S1 verification on every request.
    observer_sync_self_heal_last_attempt_ms: std::sync::Arc<std::sync::atomic::AtomicU64>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProviderQuotaIncident {
    pub identity_key: String,
    pub incident_id: String,
    pub revision: i64,
    pub consecutive_failures: i64,
    pub next_retry_at: Option<String>,
    pub last_failure_kind: Option<String>,
    pub last_model_ref: Option<String>,
    pub opened_at: String,
    pub last_failed_at: String,
    pub resolved_at: Option<String>,
}

impl fmt::Debug for RuntimeDb {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("RuntimeDb")
            .field("path", &self.path)
            .field("lock_path", &self.lock_path)
            .finish_non_exhaustive()
    }
}

#[derive(Debug)]
pub struct RuntimeDbLock {
    file: File,
    path: PathBuf,
}

impl RuntimeDb {
    pub fn open_and_migrate(
        path: impl Into<PathBuf>,
        lock_path: impl Into<PathBuf>,
    ) -> Result<Self> {
        let path = path.into();
        let writer = RuntimeDbWriter::open_starting(path.clone(), open_connection(&path)?)?;
        let db = Self {
            writer,
            path,
            lock_path: lock_path.into(),
            observer_sync_self_heal_last_attempt_ms: std::sync::Arc::new(
                std::sync::atomic::AtomicU64::new(0),
            ),
        };
        db.migrate()?;
        db.writer.activate_sidecar_protection()?;
        Ok(db)
    }

    /// Opens an existing database for the offline scheduler recovery command.
    ///
    /// Recovery must be able to inspect and settle schema 46 rows that block
    /// the destructive scheduler-schema migration. All other callers must use
    /// [`Self::open_and_migrate`].
    pub fn open_for_scheduler_recovery(
        path: impl Into<PathBuf>,
        lock_path: impl Into<PathBuf>,
    ) -> Result<Self> {
        let path = path.into();
        if !path.is_file() {
            bail!(
                "scheduler recovery requires an existing runtime database: {}",
                path.display()
            );
        }
        let connection = open_connection(&path)?;
        configure_persistent_database(&connection)?;
        let writer = RuntimeDbWriter::open_starting(path.clone(), connection)?;
        let db = Self {
            writer,
            path,
            observer_sync_self_heal_last_attempt_ms: std::sync::Arc::new(
                std::sync::atomic::AtomicU64::new(0),
            ),
            lock_path: lock_path.into(),
        };
        let current_version: i64 = db.connection()?.query_row(
            "SELECT COALESCE(MAX(version), 0) FROM schema_migrations",
            [],
            |row| row.get(0),
        )?;
        let max_known_version = max_known_migration_version();
        if !(RETIRED_SCHEDULER_SCHEMA_PREDECESSOR..=max_known_version).contains(&current_version) {
            bail!(
                "scheduler recovery supports runtime db schemas {} through {}, found {}",
                RETIRED_SCHEDULER_SCHEMA_PREDECESSOR,
                max_known_version,
                current_version
            );
        }
        db.writer.activate_sidecar_protection()?;
        Ok(db)
    }

    /// Opens an existing database for an explicit Agent relation report or
    /// pre-migration backup without applying schema migrations.
    pub fn open_for_agent_relation_backfill(
        path: impl Into<PathBuf>,
        lock_path: impl Into<PathBuf>,
    ) -> Result<Self> {
        let path = path.into();
        if !path.is_file() {
            bail!(
                "agent relation backfill requires an existing runtime database: {}",
                path.display()
            );
        }
        let connection = open_connection(&path)?;
        configure_persistent_database(&connection)?;
        let writer = RuntimeDbWriter::open_starting(path.clone(), connection)?;
        let db = Self {
            writer,
            path,
            observer_sync_self_heal_last_attempt_ms: std::sync::Arc::new(
                std::sync::atomic::AtomicU64::new(0),
            ),
            lock_path: lock_path.into(),
        };
        let current_version = db.current_schema_version()?;
        let max_known_version = max_known_migration_version();
        if !(AGENT_CANONICAL_RELATIONS_SCHEMA_VERSION..=max_known_version)
            .contains(&current_version)
        {
            bail!(
                "agent relation backfill supports runtime db schemas {} through {}, found {}",
                AGENT_CANONICAL_RELATIONS_SCHEMA_VERSION,
                max_known_version,
                current_version
            );
        }
        db.writer.activate_sidecar_protection()?;
        Ok(db)
    }

    /// Opens an existing database for the explicit v66 data-only marker rollback
    /// without applying migrations.
    pub fn open_for_conversation_input_assignment_rollback(
        path: impl Into<PathBuf>,
        lock_path: impl Into<PathBuf>,
    ) -> Result<Self> {
        let path = path.into();
        if !path.is_file() {
            bail!(
                "conversation input assignment rollback requires an existing runtime database: {}",
                path.display()
            );
        }
        let connection = open_connection(&path)?;
        configure_persistent_database(&connection)?;
        let has_migration_table: bool = connection.query_row(
            "SELECT EXISTS(
               SELECT 1 FROM sqlite_master
               WHERE type = 'table' AND name = 'schema_migrations'
             )",
            [],
            |row| row.get(0),
        )?;
        if !has_migration_table {
            bail!(
                "conversation input assignment rollback requires schema_migrations in {}",
                path.display()
            );
        }
        let writer = RuntimeDbWriter::open_starting(path.clone(), connection)?;
        let db = Self {
            writer,
            path,
            observer_sync_self_heal_last_attempt_ms: std::sync::Arc::new(
                std::sync::atomic::AtomicU64::new(0),
            ),
            lock_path: lock_path.into(),
        };
        db.writer.activate_sidecar_protection()?;
        Ok(db)
    }

    /// Opens an existing, current-schema database for offline turn settlement
    /// repair without applying migrations.
    pub fn open_for_turn_settlement_repair(
        path: impl Into<PathBuf>,
        lock_path: impl Into<PathBuf>,
    ) -> Result<Self> {
        let path = path.into();
        if !path.is_file() {
            bail!(
                "turn settlement repair requires an existing runtime database: {}",
                path.display()
            );
        }
        let connection = open_connection(&path)?;
        let has_migration_table: bool = connection.query_row(
            "SELECT EXISTS(
               SELECT 1 FROM sqlite_master
               WHERE type = 'table' AND name = 'schema_migrations'
             )",
            [],
            |row| row.get(0),
        )?;
        if !has_migration_table {
            bail!(
                "turn settlement repair requires schema_migrations in {}",
                path.display()
            );
        }
        let schema_version: i64 = connection.query_row(
            "SELECT COALESCE(MAX(version), 0) FROM schema_migrations",
            [],
            |row| row.get(0),
        )?;
        let expected_schema_version = max_known_migration_version();
        if schema_version != expected_schema_version {
            bail!(
                "turn settlement repair requires runtime db schema {}, found {}",
                expected_schema_version,
                schema_version
            );
        }
        let writer = RuntimeDbWriter::open_starting(path.clone(), connection)?;
        let db = Self {
            writer,
            path,
            observer_sync_self_heal_last_attempt_ms: std::sync::Arc::new(
                std::sync::atomic::AtomicU64::new(0),
            ),
            lock_path: lock_path.into(),
        };
        db.writer.activate_sidecar_protection()?;
        Ok(db)
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    pub fn lock_path(&self) -> &Path {
        &self.lock_path
    }

    pub fn connection(&self) -> Result<Connection> {
        self.writer.open_connection()
    }

    pub fn record_provider_quota_failure(
        &self,
        identity_key: &str,
        incident_id: &str,
        failed_at: &str,
        next_retry_at: Option<&str>,
        failure_kind: &str,
        model_ref: &str,
    ) -> Result<ProviderQuotaIncident> {
        self.transaction(|tx| {
            tx.execute(
                "INSERT INTO provider_quota_incidents (
                    identity_key, incident_id, revision, consecutive_failures,
                    next_retry_at, last_failure_kind, last_model_ref,
                    opened_at, last_failed_at, resolved_at
                 ) VALUES (?1, ?2, 1, 1, ?3, ?4, ?5, ?6, ?6, NULL)
                 ON CONFLICT(identity_key) DO UPDATE SET
                    revision = provider_quota_incidents.revision + 1,
                    consecutive_failures = CASE
                        WHEN provider_quota_incidents.resolved_at IS NULL
                        THEN provider_quota_incidents.consecutive_failures + 1
                        ELSE 1
                    END,
                    incident_id = CASE
                        WHEN provider_quota_incidents.resolved_at IS NULL
                        THEN provider_quota_incidents.incident_id
                        ELSE excluded.incident_id
                    END,
                    next_retry_at = excluded.next_retry_at,
                    last_failure_kind = excluded.last_failure_kind,
                    last_model_ref = excluded.last_model_ref,
                    last_failed_at = excluded.last_failed_at,
                    opened_at = CASE
                        WHEN provider_quota_incidents.resolved_at IS NULL
                        THEN provider_quota_incidents.opened_at
                        ELSE excluded.opened_at
                    END,
                    resolved_at = NULL",
                rusqlite::params![
                    identity_key,
                    incident_id,
                    next_retry_at,
                    failure_kind,
                    model_ref,
                    failed_at
                ],
            )?;
            Ok(tx.query_row(
                "SELECT identity_key, incident_id, revision, consecutive_failures,
                        next_retry_at, last_failure_kind, last_model_ref,
                        opened_at, last_failed_at, resolved_at
                 FROM provider_quota_incidents WHERE identity_key = ?1",
                [identity_key],
                |row| {
                    Ok(ProviderQuotaIncident {
                        identity_key: row.get(0)?,
                        incident_id: row.get(1)?,
                        revision: row.get(2)?,
                        consecutive_failures: row.get(3)?,
                        next_retry_at: row.get(4)?,
                        last_failure_kind: row.get(5)?,
                        last_model_ref: row.get(6)?,
                        opened_at: row.get(7)?,
                        last_failed_at: row.get(8)?,
                        resolved_at: row.get(9)?,
                    })
                },
            )?)
        })
    }

    pub fn provider_quota_incident(
        &self,
        identity_key: &str,
    ) -> Result<Option<ProviderQuotaIncident>> {
        self.connection()?
            .query_row(
                "SELECT identity_key, incident_id, revision, consecutive_failures,
                    next_retry_at, last_failure_kind, last_model_ref,
                    opened_at, last_failed_at, resolved_at
             FROM provider_quota_incidents WHERE identity_key = ?1",
                [identity_key],
                |row| {
                    Ok(ProviderQuotaIncident {
                        identity_key: row.get(0)?,
                        incident_id: row.get(1)?,
                        revision: row.get(2)?,
                        consecutive_failures: row.get(3)?,
                        next_retry_at: row.get(4)?,
                        last_failure_kind: row.get(5)?,
                        last_model_ref: row.get(6)?,
                        opened_at: row.get(7)?,
                        last_failed_at: row.get(8)?,
                        resolved_at: row.get(9)?,
                    })
                },
            )
            .optional()
            .map_err(Into::into)
    }

    pub fn update_provider_quota_retry_at(
        &self,
        identity_key: &str,
        next_retry_at: &str,
    ) -> Result<()> {
        self.transaction(|tx| {
            tx.execute(
                "UPDATE provider_quota_incidents
                 SET revision = revision + 1, next_retry_at = ?2
                 WHERE identity_key = ?1 AND resolved_at IS NULL",
                rusqlite::params![identity_key, next_retry_at],
            )?;
            Ok(())
        })
    }

    pub fn resolve_provider_quota_incident(
        &self,
        identity_key: &str,
        resolved_at: &str,
    ) -> Result<bool> {
        self.transaction(|tx| {
            let updated = tx.execute(
                "UPDATE provider_quota_incidents
                 SET revision = revision + 1, consecutive_failures = 0,
                     next_retry_at = NULL, resolved_at = ?2
                 WHERE identity_key = ?1 AND resolved_at IS NULL",
                rusqlite::params![identity_key, resolved_at],
            )?;
            Ok(updated == 1)
        })
    }

    pub fn protection_status(&self) -> RuntimeDbProtectionStatus {
        self.writer.protection_status()
    }

    pub(crate) fn create_verified_backup(&self, label: &str) -> Result<PathBuf> {
        let timestamp = Utc::now().format("%Y%m%dT%H%M%S%.9fZ");
        let file_name = self
            .path
            .file_name()
            .and_then(|name| name.to_str())
            .unwrap_or("runtime.sqlite");
        let backup_path = self
            .path
            .with_file_name(format!("{file_name}.{label}.{timestamp}.bak"));
        if backup_path.exists() {
            bail!(
                "runtime database backup already exists: {}",
                backup_path.display()
            );
        }
        let backup_path_text = backup_path.to_string_lossy().into_owned();
        self.connection()?
            .execute("VACUUM INTO ?1", [&backup_path_text])
            .with_context(|| {
                format!("creating runtime database backup {}", backup_path.display())
            })?;
        File::open(&backup_path)?.sync_all()?;
        let integrity: String =
            open_connection(&backup_path)?
                .query_row("PRAGMA integrity_check", [], |row| row.get(0))?;
        if integrity != "ok" {
            bail!(
                "runtime database backup {} failed integrity check: {integrity}",
                backup_path.display()
            );
        }
        Ok(backup_path)
    }

    pub fn create_scheduler_recovery_backup(&self) -> Result<PathBuf> {
        self.create_verified_backup("scheduler-recovery")
    }

    pub fn create_agent_relation_backfill_backup(&self) -> Result<PathBuf> {
        self.create_verified_backup("agent-relation-backfill")
    }

    pub fn plan_conversation_input_assignment_rollback(
        &self,
    ) -> Result<ConversationInputAssignmentRollbackReport> {
        let connection = self.connection()?;
        let head = migration_head(&connection)?;
        let target = MIGRATIONS
            .iter()
            .find(|migration| migration.version == CONVERSATION_INPUT_ASSIGNMENT_REPAIR_VERSION - 1)
            .context("missing conversation input assignment rollback target migration")?;
        let (current_version, current_name) = head
            .clone()
            .map(|(version, name)| (version, Some(name)))
            .unwrap_or((0, None));
        let eligible = matches!(
            head.as_ref(),
            Some((version, name))
                if *version == CONVERSATION_INPUT_ASSIGNMENT_REPAIR_VERSION
                    && name == CONVERSATION_INPUT_ASSIGNMENT_REPAIR_NAME
        );
        let reason = (!eligible).then(|| match head {
            Some((version, name)) if version > CONVERSATION_INPUT_ASSIGNMENT_REPAIR_VERSION => {
                format!(
                    "runtime database has newer migration {version} ({name}); refusing to remove v66"
                )
            }
            Some((version, name)) if version == CONVERSATION_INPUT_ASSIGNMENT_REPAIR_VERSION => {
                format!(
                    "migration v66 name mismatch: expected {}, found {name}",
                    CONVERSATION_INPUT_ASSIGNMENT_REPAIR_NAME
                )
            }
            Some((version, name)) => format!(
                "runtime database head is v{version} ({name}); v66 data-only marker is not applied"
            ),
            None => "runtime database has no applied migrations".to_string(),
        });
        Ok(ConversationInputAssignmentRollbackReport {
            apply: false,
            eligible,
            changed: false,
            backup_verified: false,
            database_path: self.path.clone(),
            current_version,
            current_name,
            target_version: target.version,
            target_name: target.name.to_string(),
            backup_path: None,
            reason,
        })
    }

    pub fn apply_conversation_input_assignment_rollback(
        &self,
    ) -> Result<ConversationInputAssignmentRollbackReport> {
        let mut report = self.plan_conversation_input_assignment_rollback()?;
        if !report.eligible {
            bail!(
                "{}",
                report
                    .reason
                    .as_deref()
                    .unwrap_or("runtime database is not eligible for v66 rollback")
            );
        }
        let backup_path =
            self.create_verified_backup("conversation-input-assignment-v66-to-v65")?;
        let backup_head = migration_head(&open_connection(&backup_path)?)?;
        if backup_head
            != Some((
                CONVERSATION_INPUT_ASSIGNMENT_REPAIR_VERSION,
                CONVERSATION_INPUT_ASSIGNMENT_REPAIR_NAME.to_string(),
            ))
        {
            bail!(
                "runtime database backup {} does not preserve the expected v66 marker",
                backup_path.display()
            );
        }
        self.transaction_once(|transaction| {
            let changed = transaction.execute(
                "DELETE FROM schema_migrations WHERE version = ?1 AND name = ?2",
                (
                    CONVERSATION_INPUT_ASSIGNMENT_REPAIR_VERSION,
                    CONVERSATION_INPUT_ASSIGNMENT_REPAIR_NAME,
                ),
            )?;
            if changed != 1 {
                bail!(
                    "expected to remove exactly one v66 conversation input assignment marker, removed {changed}"
                );
            }
            let head = migration_head(transaction)?;
            if head != Some((report.target_version, report.target_name.clone())) {
                bail!(
                    "runtime database head after v66 rollback is {:?}, expected v{} ({})",
                    head,
                    report.target_version,
                    report.target_name
                );
            }
            Ok(())
        })?;
        report.apply = true;
        report.changed = true;
        report.backup_verified = true;
        report.backup_path = Some(backup_path);
        report.current_version = report.target_version;
        report.current_name = Some(report.target_name.clone());
        report.reason = None;
        Ok(report)
    }

    /// Run a transaction, retrying body lock errors only after a confirmed rollback.
    ///
    /// The callback must not control the transaction or perform external effects:
    /// it may run more than once. Failure certainty is available through
    /// [`persistence_certainty`]; an indeterminate result must be reconciled before replay.
    pub fn transaction<T>(&self, f: impl FnMut(&Transaction<'_>) -> Result<T>) -> Result<T> {
        self.writer.append_wait(f)
    }

    fn transaction_with_context<T>(
        &self,
        context: RuntimeDbWriteContext,
        f: impl FnMut(&Transaction<'_>) -> Result<T>,
    ) -> Result<T> {
        self.writer.append_wait_with_context(context, f)
    }

    pub(crate) fn transaction_once<T>(
        &self,
        f: impl FnOnce(&Transaction<'_>) -> Result<T>,
    ) -> Result<T> {
        self.writer.append_wait_once(f)
    }

    /// Enqueue a background transaction. Success means queue acceptance, not commit.
    pub fn append(
        &self,
        f: impl for<'transaction> Fn(&Transaction<'transaction>) -> Result<()> + Send + 'static,
    ) -> Result<()> {
        self.writer.append(f)
    }

    #[cfg(test)]
    pub(crate) fn flush_background_writes_for_tests(&self) -> Result<()> {
        self.writer.flush_background_writes_for_tests()
    }

    pub fn current_schema_version(&self) -> Result<i64> {
        let connection = self.connection()?;
        current_schema_version(&connection)
    }

    pub fn retired_scheduler_cleanup_inventory(&self) -> Result<RetiredSchedulerCleanupInventory> {
        let connection = self.connection()?;
        retired_scheduler_cleanup::retired_scheduler_cleanup_inventory(&connection)
    }

    pub fn apply_retired_scheduler_cleanup_fallback(
        &self,
        agent_id: &str,
    ) -> Result<RetiredSchedulerFallbackResult> {
        self.apply_retired_scheduler_cleanup_fallbacks(&[agent_id.to_string()])
            .map(|mut results| {
                results
                    .pop()
                    .expect("one fallback result is returned for one agent")
            })
    }

    pub fn apply_retired_scheduler_cleanup_fallbacks(
        &self,
        agent_ids: &[String],
    ) -> Result<Vec<RetiredSchedulerFallbackResult>> {
        self.apply_retired_scheduler_cleanup_fallbacks_inner(agent_ids, None)
    }

    pub fn apply_retired_scheduler_cleanup_fallbacks_with_maintenance(
        &self,
        agent_ids: &[String],
        maintenance: &OfflineInputMaintenance<'_>,
    ) -> Result<Vec<RetiredSchedulerFallbackResult>> {
        self.apply_retired_scheduler_cleanup_fallbacks_inner(agent_ids, Some(maintenance))
    }

    fn apply_retired_scheduler_cleanup_fallbacks_inner(
        &self,
        agent_ids: &[String],
        maintenance: Option<&OfflineInputMaintenance<'_>>,
    ) -> Result<Vec<RetiredSchedulerFallbackResult>> {
        self.transaction(|tx| {
            agent_ids
                .iter()
                .map(|agent_id| {
                    retired_scheduler_cleanup::apply_retired_scheduler_cleanup_fallback(
                        tx,
                        self,
                        agent_id,
                        maintenance,
                    )
                })
                .collect()
        })
    }

    pub fn work_items(&self) -> WorkItemRepository<'_> {
        WorkItemRepository { db: self }
    }

    pub fn tasks(&self) -> TaskRepository<'_> {
        TaskRepository { db: self }
    }

    pub fn external_triggers(&self) -> ExternalTriggerRepository<'_> {
        ExternalTriggerRepository { db: self }
    }

    pub fn wait_conditions(&self) -> WaitConditionRepository<'_> {
        WaitConditionRepository { db: self }
    }

    pub fn queue_entries(&self) -> QueueEntryRepository<'_> {
        QueueEntryRepository { db: self }
    }

    pub fn timers(&self) -> TimerRepository<'_> {
        TimerRepository { db: self }
    }

    pub fn turn_records(&self) -> TurnRecordRepository<'_> {
        TurnRecordRepository { db: self }
    }

    pub fn destructive_operations(&self) -> DestructiveOperationRepository<'_> {
        DestructiveOperationRepository { db: self }
    }

    pub fn conversation(&self) -> ConversationRepository<'_> {
        ConversationRepository { db: self }
    }

    pub fn content_reports(&self) -> ContentReportRepository<'_> {
        ContentReportRepository { db: self }
    }

    pub fn messages(&self) -> MessageRepository<'_> {
        MessageRepository { db: self }
    }

    pub fn transcript_entries(&self) -> TranscriptRepository<'_> {
        TranscriptRepository { db: self }
    }

    pub fn evidence(&self) -> EvidenceRepository<'_> {
        EvidenceRepository { db: self }
    }

    pub fn audit_events(&self) -> AuditEventSink<'_> {
        AuditEventSink { db: self }
    }

    pub fn authentication(&self) -> AuthenticationRepository<'_> {
        AuthenticationRepository { db: self }
    }

    pub fn agent_states(&self) -> AgentStateRepository<'_> {
        AgentStateRepository { db: self }
    }

    pub fn workspace_entries(&self) -> WorkspaceEntryRepository<'_> {
        WorkspaceEntryRepository { db: self }
    }

    pub fn workspace_occupancies(&self) -> WorkspaceOccupancyRepository<'_> {
        WorkspaceOccupancyRepository { db: self }
    }

    pub fn execution_root_entries(&self) -> ExecutionRootEntryRepository<'_> {
        ExecutionRootEntryRepository { db: self }
    }

    pub fn agent_identities(&self) -> AgentIdentityRepository<'_> {
        AgentIdentityRepository { db: self }
    }

    pub fn agent_canonical_relations(&self) -> AgentCanonicalRelationRepository<'_> {
        AgentCanonicalRelationRepository { db: self }
    }

    pub fn agent_bootstraps(&self) -> AgentBootstrapRepository<'_> {
        AgentBootstrapRepository { db: self }
    }

    pub fn agent_deletions(&self) -> AgentDeletionRepository<'_> {
        AgentDeletionRepository { db: self }
    }

    pub fn agent_message_deliveries(&self) -> AgentMessageDeliveryRepository<'_> {
        AgentMessageDeliveryRepository { db: self }
    }

    pub fn work_item_delegations(&self) -> WorkItemDelegationRepository<'_> {
        WorkItemDelegationRepository { db: self }
    }

    pub fn work_item_continuations(&self) -> WorkItemContinuationRepository<'_> {
        WorkItemContinuationRepository { db: self }
    }

    pub fn context_episodes(&self) -> ContextEpisodeRepository<'_> {
        ContextEpisodeRepository { db: self }
    }

    pub fn operator_notifications(&self) -> OperatorNotificationRepository<'_> {
        OperatorNotificationRepository { db: self }
    }

    pub fn operator_transport_bindings(&self) -> OperatorTransportBindingRepository<'_> {
        OperatorTransportBindingRepository { db: self }
    }

    pub fn operator_delivery_records(&self) -> OperatorDeliveryRepository<'_> {
        OperatorDeliveryRepository { db: self }
    }

    pub fn runtime_index_outbox(&self) -> RuntimeIndexOutboxRepository<'_> {
        RuntimeIndexOutboxRepository { db: self }
    }

    pub const fn expected_storage_domains() -> &'static [ExpectedStorageDomain] {
        &[
            ExpectedStorageDomain {
                domain: "agent_states",
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: "workspace_entries",
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: "workspace_occupancies",
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: "agent_identities",
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: "work_items",
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: "work_item_delegations",
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: "work_item_continuations",
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: CONTEXT_EPISODE_ANCHORS_DOMAIN,
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: "tasks",
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: "external_triggers",
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: "wait_conditions",
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: "queue_entries",
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: "timers",
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: "turn_records",
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: "messages",
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: "transcript_entries",
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: "evidence",
                canonical_source: "db",
            },
            ExpectedStorageDomain {
                domain: "audit_events",
                canonical_source: "db",
            },
        ]
    }

    pub fn storage_domain(&self, domain: &str) -> Result<Option<StorageDomainSnapshot>> {
        let connection = self.connection()?;
        read_storage_domain_connection(&connection, domain)
    }

    pub fn storage_domains(&self) -> Result<Vec<StorageDomainSnapshot>> {
        let connection = self.connection()?;
        let mut statement = connection.prepare(
            "SELECT domain, schema_version, import_status, canonical_source,
                    source_checkpoint_json, imported_at, updated_at
             FROM storage_domains
             ORDER BY domain ASC",
        )?;
        let rows = statement.query_map([], |row| {
            Ok(StorageDomainSnapshot {
                domain: row.get(0)?,
                schema_version: row.get(1)?,
                import_status: row.get(2)?,
                canonical_source: row.get(3)?,
                source_checkpoint_json: row.get(4)?,
                imported_at: row.get(5)?,
                updated_at: row.get(6)?,
            })
        })?;
        rows.map(|row| row.map_err(Into::into)).collect()
    }

    pub fn diagnose_cutover(&self, expected: &[ExpectedStorageDomain]) -> Result<Vec<String>> {
        let connection = self.connection()?;
        let mut diagnostics = Vec::new();
        let current_version = current_schema_version(&connection)?;
        let max_known_version = max_known_migration_version();
        if current_version < max_known_version {
            diagnostics.push(format!(
                "missing runtime db migration: schema_migrations is at {current_version}, expected {max_known_version}"
            ));
        }
        for expected_domain in expected {
            // Success diagnostics inspect marker metadata only. A complete
            // original v1 footprint can contain 100k SQL-held records.
            let marker:Option<(String,String,Option<String>)>=connection.query_row(
                "SELECT import_status,canonical_source,CASE WHEN import_status='failed' THEN source_checkpoint_json ELSE NULL END FROM storage_domains WHERE domain=?1",
                [expected_domain.domain],|row|Ok((row.get(0)?,row.get(1)?,row.get(2)?)),
            ).optional()?;
            match marker {
                None => diagnostics.push(format!(
                    "storage domain {} is missing; expected canonical_source={}",
                    expected_domain.domain, expected_domain.canonical_source
                )),
                Some((import_status, canonical_source, failure_checkpoint)) => {
                    if import_status == "failed" {
                        diagnostics.push(format!(
                            "storage domain {} import failed: {}",
                            expected_domain.domain,
                            failure_checkpoint
                                .as_deref()
                                .unwrap_or("no failure checkpoint recorded")
                        ));
                    } else if import_status != "complete" {
                        diagnostics.push(format!(
                            "storage domain {} import is {}; expected complete",
                            expected_domain.domain, import_status
                        ));
                    }
                    if canonical_source != expected_domain.canonical_source {
                        diagnostics.push(format!(
                            "storage domain {} has canonical_source={}; expected {}",
                            expected_domain.domain,
                            canonical_source,
                            expected_domain.canonical_source
                        ));
                    }
                }
            }
        }
        Ok(diagnostics)
    }

    pub fn validate_expected_storage_domains(
        &self,
        expected: &[ExpectedStorageDomain],
    ) -> Result<()> {
        let diagnostics = self.diagnose_cutover(expected)?;
        if diagnostics.is_empty() {
            return Ok(());
        }
        bail!(
            "runtime db cutover diagnostics failed:\n{}",
            diagnostics.join("\n")
        )
    }

    pub(crate) fn storage_domain_is_complete(
        &self,
        domain: &str,
        canonical_source: &str,
    ) -> Result<bool> {
        let connection = self.connection()?;
        connection.query_row(
            "SELECT EXISTS(SELECT 1 FROM storage_domains WHERE domain=?1 AND import_status='complete' AND canonical_source=?2)",
            rusqlite::params![domain,canonical_source],|row|row.get(0),
        ).map_err(Into::into)
    }

    fn run_storage_domain_import(
        &self,
        domain: &'static str,
        importing_source: &'static str,
        complete_source: &'static str,
        import: impl FnOnce(&Transaction<'_>) -> Result<serde_json::Value>,
    ) -> Result<()> {
        self.transaction(|tx| {
            let existing_checkpoint = tx
                .query_row(
                    "SELECT source_checkpoint_json FROM storage_domains WHERE domain = ?1",
                    [domain],
                    |row| row.get::<_, Option<String>>(0),
                )
                .optional()?
                .flatten();
            upsert_storage_domain_checkpoint_json(
                tx,
                domain,
                "importing",
                importing_source,
                existing_checkpoint,
            )
        })?;
        let result = self.transaction_once(|tx| {
            let checkpoint = import(tx)?;
            upsert_storage_domain(tx, domain, "complete", complete_source, Some(checkpoint))?;
            Ok(())
        });
        if let Err(error) = result {
            let checkpoint = serde_json::json!({
                "error": error.to_string(),
                "retry": "restart runtime to retry legacy import",
            });
            self.transaction_once(|tx| {
                upsert_storage_domain(tx, domain, "failed", importing_source, Some(checkpoint))
            })?;
            return Err(error).with_context(|| format!("importing legacy storage domain {domain}"));
        }
        Ok(())
    }

    pub fn migrate(&self) -> Result<()> {
        let _lock = RuntimeDbLock::lock(&self.lock_path)?;
        if let Some(parent) = self.path.parent() {
            fs::create_dir_all(parent)
                .with_context(|| format!("creating runtime db directory {}", parent.display()))?;
        }
        let _turn = self.writer.state.queue.wait_turn()?;
        let mut connection = self
            .writer
            .state
            .connection
            .lock()
            .map_err(|_| anyhow!("runtime db writer mutex poisoned"))?;
        configure_new_database_auto_vacuum(&connection)?;
        configure_persistent_database(&connection)?;
        ensure_migration_table(&connection)?;
        let current_version = current_schema_version(&connection)?;
        let max_known_version = max_known_migration_version();
        if current_version > max_known_version {
            bail!(
                "runtime db schema version {} is newer than this binary supports ({})",
                current_version,
                max_known_version
            );
        }
        if current_version <= PUBLISHED_MIGRATION_FLOOR
            && max_known_version >= RELEASE_BASELINE_TARGET
        {
            for migration in MIGRATIONS
                .iter()
                .filter(|migration| migration.version <= PUBLISHED_MIGRATION_FLOOR)
            {
                apply_migration(&mut connection, migration)?;
            }
            apply_release_baseline(&mut connection)?;
            for migration in MIGRATIONS
                .iter()
                .filter(|migration| migration.version > RELEASE_BASELINE_TARGET)
            {
                apply_migration(&mut connection, migration)?;
            }
        } else {
            for migration in MIGRATIONS {
                apply_migration(&mut connection, migration)?;
            }
        }
        ensure_runtime_identity_metadata(&connection)?;
        backfill_wait_condition_payload_columns(&connection)?;
        backfill_work_item_recheck_columns(&connection)?;
        backfill_work_item_blocker_wait_provenance(&connection)?;
        observer_sync::verify_observer_sync_foundations(&mut connection)?;
        Ok(())
    }

    pub fn event_log_epoch(&self) -> Result<String> {
        let connection = self.connection()?;
        connection
            .query_row(
                "SELECT value FROM runtime_metadata WHERE key = 'event_log_epoch'",
                [],
                |row| row.get(0),
            )
            .context("runtime event-log epoch is missing")
    }

    /// Stable public identity of this runtime installation. Survives
    /// restarts and ordinary reopens; a replaced or rebuilt database mints a
    /// new one. Not a secret.
    pub fn runtime_id(&self) -> Result<String> {
        let connection = self.connection()?;
        connection
            .query_row(
                "SELECT value FROM runtime_metadata WHERE key = 'runtime_id'",
                [],
                |row| row.get(0),
            )
            .context("runtime installation id is missing")
    }

    /// Monotone visibility policy generation. Bumping it rotates every
    /// derived `visibility_scope_id` without touching the event-log epoch.
    pub fn visibility_policy_generation(&self) -> Result<u64> {
        let connection = self.connection()?;
        let value: String = connection
            .query_row(
                "SELECT value FROM runtime_metadata WHERE key = 'visibility_policy_generation'",
                [],
                |row| row.get(0),
            )
            .context("visibility policy generation is missing")?;
        value
            .parse()
            .with_context(|| format!("invalid visibility policy generation {value}"))
    }
}

fn ensure_runtime_identity_metadata(connection: &Connection) -> Result<()> {
    let now = chrono::Utc::now().to_rfc3339_opts(chrono::SecondsFormat::Millis, true);
    connection.execute(
        "INSERT OR IGNORE INTO runtime_metadata (key, value, created_at, updated_at)
         VALUES ('event_log_epoch', ?1, ?2, ?2)",
        rusqlite::params![crate::ids::event_log_epoch_id(), now],
    )?;
    connection.execute(
        "INSERT OR IGNORE INTO runtime_metadata (key, value, created_at, updated_at)
         VALUES ('runtime_id', ?1, ?2, ?2)",
        rusqlite::params![crate::ids::runtime_installation_id(), now],
    )?;
    connection.execute(
        "INSERT OR IGNORE INTO runtime_metadata (key, value, created_at, updated_at)
         VALUES ('visibility_policy_generation', '0', ?1, ?1)",
        rusqlite::params![now],
    )?;
    connection.execute(
        "INSERT OR IGNORE INTO runtime_metadata (key, value, created_at, updated_at)
         VALUES ('conversation_cursor_signing_key', ?1, ?2, ?2)",
        rusqlite::params![crate::ids::capability_id("conversation_cursor"), now],
    )?;
    Ok(())
}

fn migration_head(connection: &Connection) -> Result<Option<(i64, String)>> {
    connection
        .query_row(
            "SELECT version, name
             FROM schema_migrations
             ORDER BY version DESC
             LIMIT 1",
            [],
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .optional()
        .map_err(Into::into)
}

impl RuntimeDbLock {
    pub fn lock(path: impl Into<PathBuf>) -> Result<Self> {
        Self::open(path.into(), LockMode::Blocking)
    }

    pub fn try_lock(path: impl Into<PathBuf>) -> Result<Self> {
        Self::open(path.into(), LockMode::NonBlocking)
    }

    fn open(path: PathBuf, mode: LockMode) -> Result<Self> {
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)
                .with_context(|| format!("creating runtime lock directory {}", parent.display()))?;
        }
        let file = OpenOptions::new()
            .create(true)
            .read(true)
            .write(true)
            .open(&path)
            .with_context(|| format!("opening runtime db lock {}", path.display()))?;
        flock(&file, mode).with_context(|| format!("locking runtime db {}", path.display()))?;
        Ok(Self { file, path })
    }

    pub fn path(&self) -> &Path {
        &self.path
    }
}

impl Drop for RuntimeDbLock {
    fn drop(&mut self) {
        let _ = unlock(&self.file);
    }
}
