//! Bounded canonical metadata under an existing mutation owner; no read authority.
use super::repositories::{decode_agent_identity_payload, decode_agent_state_payload};
use crate::{
    runtime::{
        input_evidence_budget::{BudgetViewGuard, InputEvidenceBudgetLedger, InputMemoryCategory, OwnedBytesEstimate, OwnedCompletionBudget},
        resident_input_evidence::InputEvidenceScope,
    },
    types::{AgentIdentityRecord, AgentState},
};
use anyhow::{ensure, Context, Result};
use rusqlite::{OptionalExtension, Transaction};
use std::sync::Arc;

#[derive(Debug, thiserror::Error)]
#[error("ResourceExhausted: mutation canonical metadata")]
pub(crate) struct MutationCanonicalMaterialExhausted;

/// The allocation owner and the observed durable identity are deliberately
/// separate. Reading a successor header never grants access to its State.
#[derive(Debug)]
pub(crate) struct MutationCanonicalFacts {
    pub(crate) identity: Option<Arc<AgentIdentityRecord>>,
    pub(crate) state: Option<Arc<AgentState>>,
    allocation_scope: InputEvidenceScope,
    ledger: InputEvidenceBudgetLedger,
    cost: (u64, usize),
    guard: Arc<BudgetViewGuard>,
}
impl MutationCanonicalFacts {
    pub(crate) fn material_estimate(&self) -> (u64, usize) { self.cost }
    pub(crate) fn visit_material(
        &self,
        scope: &InputEvidenceScope,
        ledger: &InputEvidenceBudgetLedger,
        visit: &mut impl FnMut(&Arc<BudgetViewGuard>, u64, usize) -> Result<()>,
    ) -> Result<()> {
        ensure!(self.allocation_scope == *scope && self.ledger.same_ledger(ledger),
            "mutation canonical allocation belongs to another owner scope/ledger");
        self.guard.validate_owned_material_binding(scope, ledger, self.cost.0)?;
        visit(&self.guard, self.cost.0, self.cost.1)
    }
    pub(crate) fn guard(&self) -> Arc<BudgetViewGuard> {
        self.guard.clone()
    }
}

struct Phase {
    prior: (u64, usize),
    own: (u64, usize),
    limits: (usize, usize),
    material: OwnedCompletionBudget,
}
impl Phase {
    fn observe(&mut self, bytes: u64, nodes: usize) -> Result<()> {
        let own = (self.own.0.checked_add(bytes), self.own.1.checked_add(nodes));
        let (Some(bytes_total), Some(nodes_total)) = own else { anyhow::bail!(MutationCanonicalMaterialExhausted) };
        ensure!(self.prior.0.checked_add(bytes_total).is_some_and(|n| n <= self.limits.0 as u64)
            && self.prior.1.checked_add(nodes_total).is_some_and(|n| n <= self.limits.1),
            MutationCanonicalMaterialExhausted);
        // The existing owned counter grows only after this phase's quota check,
        // before SQLite or Rust can allocate the next original decoder copy.
        self.material.observe_material(bytes, 0);
        self.own = (bytes_total, nodes_total);
        Ok(())
    }
    fn raw(&mut self, bytes: usize, rows: usize) -> Result<()> {
        let nodes = rows.checked_mul(8).context(MutationCanonicalMaterialExhausted)?;
        let bytes = u64::try_from(bytes)?.checked_mul(8)
            .and_then(|n| n.checked_add(u64::try_from(nodes).ok()?.checked_mul(256)?))
            .context(MutationCanonicalMaterialExhausted)?;
        self.observe(bytes, nodes)
    }
    fn native(&mut self, nodes: usize) -> Result<()> {
        let nodes = nodes.checked_mul(2).context(MutationCanonicalMaterialExhausted)?;
        self.observe(u64::try_from(nodes)?.checked_mul(256).context(MutationCanonicalMaterialExhausted)?, nodes)
    }
}

/// Called only while the original reservation is held. The caller supplies its
/// actual material prior, rather than the ledger's unrelated global usage.
pub(crate) fn read_mutation_canonical_tx(
    tx: &Transaction<'_>,
    allocation_scope: &InputEvidenceScope,
    ledger: &InputEvidenceBudgetLedger,
    observed_agent_id: &str,
    expected_incarnation: u64,
    include_state: bool,
    prior: (u64, usize),
    requested: (usize, usize),
) -> Result<Arc<MutationCanonicalFacts>> {
    ensure!(!observed_agent_id.is_empty() && expected_incarnation > 0,
        "mutation canonical expected identity is invalid");
    let allowance = ledger.limits();
    let limits = (
        requested.0.min(usize::try_from(allowance.history_per_agent_bytes
            .checked_add(allowance.pending_per_agent_bytes).context(MutationCanonicalMaterialExhausted)?
            .min(64 * 1024 * 1024))?),
        requested.1.min(usize::try_from(allowance.record_limit.min(65536))?),
    );
    let header = u64::try_from(allocation_scope.agent_id.len())?.checked_mul(8)
        .and_then(|n| n.checked_add(4096)).context(MutationCanonicalMaterialExhausted)?;
    let address_bytes = u64::try_from(allocation_scope.agent_id.len())?.checked_mul(4)
        .and_then(|n| n.checked_add(512)).context(MutationCanonicalMaterialExhausted)?;
    ensure!(prior.0.checked_add(header).and_then(|n| n.checked_add(address_bytes)).is_some_and(|n| n <= limits.0 as u64)
        && prior.1.checked_add(24).is_some_and(|n| n <= limits.1), MutationCanonicalMaterialExhausted);
    // The temporary Host guard precedes the scoped ledger-key allocation.
    let address = ledger.register_host_owned_bytes(InputMemoryCategory::Candidate,
        OwnedBytesEstimate { payload_bytes: 0, metadata_estimate_bytes: address_bytes })?;
    let material = ledger.reserve_owned_completion(allocation_scope, InputMemoryCategory::Candidate,
        OwnedBytesEstimate { payload_bytes: header, metadata_estimate_bytes: 0 })?;
    drop(address);
    let mut phase = Phase { prior, own: (header, 16), limits, material };
    let (bytes, rows): (usize, usize) = tx.query_row(
        "SELECT COALESCE(SUM(length(CAST(payload_json AS BLOB))+length(CAST(agent_id AS BLOB))+length(CAST(status AS BLOB))),0),COUNT(*) FROM agent_identities WHERE agent_id=?1",
        [observed_agent_id], |r| Ok((r.get(0)?, r.get(1)?)))?;
    phase.raw(bytes, rows)?;
    let nodes: usize = tx.query_row(
        "SELECT COUNT(*)+COUNT(CASE WHEN typeof(j.key)='text' THEN 1 END) FROM agent_identities i,json_tree(i.payload_json) j WHERE i.agent_id=?1",
        [observed_agent_id], |r| r.get(0))?;
    phase.native(nodes)?;
    let identity = tx.query_row("SELECT payload_json FROM agent_identities WHERE agent_id=?1",
        [observed_agent_id], |r| r.get::<_, String>(0)).optional()?
        .map(|payload| decode_agent_identity_payload(&payload)).transpose()?.map(Arc::new);
    if let Some(identity) = &identity {
        ensure!(identity.agent_id == observed_agent_id, "mutation canonical identity scope mismatch");
    }
    // Preserve the original absent-identity semantics. A foreign incarnation's
    // State is never queried, including scalar lengths and JSON traversal.
    let state = if include_state && identity.as_ref().is_none_or(|id| id.incarnation == expected_incarnation) {
        let (bytes, rows): (usize, usize) = tx.query_row(
            "SELECT COALESCE(SUM(length(CAST(payload_json AS BLOB))+length(CAST(agent_id AS BLOB))),0),COUNT(*) FROM agent_states WHERE agent_id=?1",
            [observed_agent_id], |r| Ok((r.get(0)?, r.get(1)?)))?;
        phase.raw(bytes, rows)?;
        let nodes: usize = tx.query_row(
            "SELECT COUNT(*)+COUNT(CASE WHEN typeof(j.key)='text' THEN 1 END) FROM agent_states s,json_tree(s.payload_json) j WHERE s.agent_id=?1",
            [observed_agent_id], |r| r.get(0))?;
        phase.native(nodes)?;
        let state = tx.query_row("SELECT payload_json FROM agent_states WHERE agent_id=?1",
            [observed_agent_id], |r| r.get::<_, String>(0)).optional()?
            .map(|payload| decode_agent_state_payload(&payload)).transpose()?.map(Arc::new);
        if let Some(state) = &state { ensure!(state.id == observed_agent_id, "mutation canonical State scope mismatch"); }
        state
    } else { None };
    Ok(Arc::new(MutationCanonicalFacts { identity, state,
        allocation_scope: allocation_scope.clone(), ledger: ledger.clone(), cost: phase.own,
        guard: phase.material.guard() }))
}
