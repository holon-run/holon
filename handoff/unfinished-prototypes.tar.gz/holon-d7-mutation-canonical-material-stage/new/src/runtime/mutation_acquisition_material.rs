//! Actual candidate/base metadata; this allocation grants no read or mutation authority.
use super::*;
use crate::runtime::input_evidence_budget::{
    borrowed_json_material, BudgetViewGuard, InputEvidenceBudgetLedger, InputMemoryCategory,
    OwnedBytesEstimate,
};
use crate::runtime::input_queries::{actual_query_material_limits, InputQueryError};
use crate::runtime::resident_input_evidence::InputEvidenceScope;
use anyhow::ensure;

#[derive(Debug)]
pub(crate) struct OriginalMutationAcquisitionMaterial {
    scope: InputEvidenceScope,
    epoch: u64,
    ledger: InputEvidenceBudgetLedger,
    cost: (u64, usize),
    total: (u64, usize),
    canonical: Vec<Arc<crate::runtime_db::mutation_canonical_material::MutationCanonicalFacts>>,
    guard: Arc<BudgetViewGuard>,
}
impl OriginalMutationAcquisitionMaterial {
    pub(crate) fn validate(
        &self,
        scope: &InputEvidenceScope,
        epoch: u64,
        ledger: &InputEvidenceBudgetLedger,
    ) -> Result<()> {
        ensure!(
            self.scope == *scope && self.epoch == epoch && self.ledger.same_ledger(ledger),
            "mutation acquisition material crossed original scope/epoch/ledger"
        );
        self.guard
            .validate_owned_material_binding(scope, ledger, self.cost.0)
            .map_err(Into::into)
    }
    pub(crate) fn material_estimate(&self) -> (u64, usize) {
        self.total
    }
    pub(super) fn with_canonical(
        mut self: Arc<Self>,
        canonical: Vec<Arc<crate::runtime_db::mutation_canonical_material::MutationCanonicalFacts>>,
    ) -> Result<Arc<Self>> {
        let actual = Arc::get_mut(&mut self).context("mutation acquisition was lent before canonical admission")?;
        for facts in &canonical {
            facts.visit_material(&actual.scope, &actual.ledger, &mut |_, _, _| Ok(()))?;
            let cost = facts.material_estimate();
            actual.total.0 = actual.total.0.checked_add(cost.0).context("canonical acquisition bytes overflow")?;
            actual.total.1 = actual.total.1.checked_add(cost.1).context("canonical acquisition nodes overflow")?;
        }
        actual.canonical = canonical;
        Ok(self)
    }
    pub(crate) fn visit_material(
        &self,
        visit: &mut impl FnMut(&Arc<BudgetViewGuard>, u64, usize) -> Result<()>,
    ) -> Result<()> {
        self.validate(&self.scope, self.epoch, &self.ledger)?;
        visit(&self.guard, self.cost.0, self.cost.1)?;
        for facts in &self.canonical {
            facts.visit_material(&self.scope, &self.ledger, visit)?;
        }
        Ok(())
    }
    pub(super) fn for_agent(
        runtime: &RuntimeHandle,
        agent: &RuntimeAgent,
        registrations: usize,
        owners: usize,
        prior: (u64, usize),
        limits: (usize, usize),
    ) -> Result<Arc<Self>> {
        let ledger = &runtime.inner.input_evidence_budget;
        let limits = actual_query_material_limits(ledger, limits)?;
        // RuntimeAgent Clone copies two State values and the abort run ID;
        // Queue Clone copies only Arc slots. Canonical Message bodies stay shared.
        let (encoded, nodes) = borrowed_json_material(&(
            &agent.state,
            &agent.last_persisted_state,
            agent
                .current_run_abort
                .as_ref()
                .map(|abort| abort.run_id.as_str()),
        ))?;
        let scope_bytes = u64::try_from(runtime.instance_agent_id().len())?;
        let slots = registrations
            .checked_add(
                agent
                    .queue
                    .len()
                    .checked_mul(2)
                    .context("mutation queue slots overflow")?,
            )
            .and_then(|n| n.checked_add(owners.checked_mul(8)?))
            .and_then(|n| n.checked_add(64))
            .context(InputQueryError::ResourceExhausted(
                "mutation acquisition slots",
            ))?;
        let nodes = nodes
            .checked_mul(2)
            .and_then(|n| n.checked_add(slots.checked_mul(4)?))
            .context(InputQueryError::ResourceExhausted(
                "mutation acquisition nodes",
            ))?;
        let bytes = encoded
            .checked_mul(2)
            .and_then(|n| n.checked_add(scope_bytes.checked_mul(8)?))
            .and_then(|n| n.checked_add(u64::try_from(nodes).ok()?.checked_mul(256)?))
            .and_then(|n| n.checked_add(8192))
            .context(InputQueryError::ResourceExhausted(
                "mutation acquisition bytes",
            ))?;
        ensure!(
            prior
                .0
                .checked_add(bytes)
                .is_some_and(|n| n <= limits.0 as u64)
                && prior.1.checked_add(nodes).is_some_and(|n| n <= limits.1),
            InputQueryError::ResourceExhausted("mutation acquisition first copy")
        );
        let address = ledger.register_host_owned_bytes(
            InputMemoryCategory::Candidate,
            OwnedBytesEstimate {
                payload_bytes: 0,
                metadata_estimate_bytes: scope_bytes
                    .checked_mul(8)
                    .and_then(|n| n.checked_add(1024))
                    .context("mutation address overflow")?,
            },
        )?;
        let scope = InputEvidenceScope {
            agent_id: runtime.instance_agent_id().into(),
            identity_incarnation: runtime.instance_incarnation(),
        };
        let guard = ledger.register_owned_bytes(
            &scope,
            InputMemoryCategory::Candidate,
            OwnedBytesEstimate {
                payload_bytes: 0,
                metadata_estimate_bytes: bytes,
            },
        )?;
        drop(address);
        Ok(Arc::new(Self {
            scope,
            epoch: runtime.instance_owner_epoch(),
            ledger: ledger.clone(),
            cost: (bytes, nodes),
            total: (bytes, nodes),
            canonical: Vec::new(),
            guard,
        }))
    }
}

#[cfg(test)]
#[path = "mutation_acquisition_material_tests.rs"]
mod tests;
